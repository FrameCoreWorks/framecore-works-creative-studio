# Poster Style and Composition Atlas

Adapted for the existing Workflow Kit role. Source: FrameCore Works,
Static Graphic Design Creator, Apache-2.0, commit
`c3cbdf766411ca7e1131bc034bfa74ebad2efe71`. Ownership and links were
adapted; upstream standalone activation, installation and execution are not imported.

Use this reference for posters, flyers, event key visuals, civic graphics, cultural graphics, and text-led social graphics. It prevents a style label from replacing a communication decision.

## Core invariant

Resolve this sequence before writing the eight-stage prompt:

`communication goal → audience response and copy burden → visual thesis → composition archetype and attention order → style family or original attributes → material treatment`

The style family supports the chosen strategy, not a decorative filter. A named artist, artwork, brand, or protected composition is never a style family; translate it into original transferable attributes under the capability and reference contract.

For detailed historical context, regional distinctions, function-specific decisions, production-process logic, and source anchors, read [the poster movements and production atlas](poster-movements-and-production-atlas.md). Keep this file as the compact routing reference.

For popular labels that mix historical languages, composition stances, image construction, digital surface treatments, and type treatments, read [the poster style translation catalog](poster-style-translation-catalog.md). Default to one primary poster language plus a compatible treatment. A requested deliberate hybrid may use more when every component has a distinct job and the reading task survives.

## Collaboration routes

Open conceptual work belongs to [concept development](concept-development-and-originality.md). When wording is also open, develop paired concept/copy candidates using the integrated copy asset (the `copy-voice` handoff), not independent style and slogan menus. A historical `discovery_brainstorm` handoff maps to this route only if its mechanism is unresolved.

After a Core Concept Lock exists, `design_direction_exploration` may vary layout, attention, image/type roles or treatment within allowed adaptations. `directed_collaboration` preserves a supplied direction and delivers the requested direction scope; raise only a material conflict, without forcing alternatives. Record the result in the existing Static Direction Contract; `strategy` and `concept` are shorthand planning notation, not a second poster-strategy schema.

## Goal classes

| Goal class | What must happen | First design priority | Common failure |
| --- | --- | --- | --- |
| Civic or social action | Understand the issue and take one action | Message mechanism, one actionable takeaway | Attractive atmosphere without an understandable issue |
| Community participation | Feel welcomed and know when and where to join | Warm signal, clear event information | Dense details competing with generic celebration imagery |
| Cultural or arts event | Feel intrigue and recognise the event | Interpretive tension, title-image relationship | Literal collage of every performer or reference |
| Music or nightlife | Feel energy and recognise the occasion | Rhythm, scale, date and venue readability | Effects piled on top of no visual idea |
| Film, theatre, or literary work | Infer a world, conflict, or question | One symbolic or narrative mechanism | Reproducing a familiar film-poster composition |
| Education, science, or public information | Understand accurately and know what to do | Information architecture, hierarchy, accessibility | Decorative style obscuring factual copy |
| Commercial conversion | Recognise product or offer and act | Product truth, offer hierarchy, CTA | Treating the product as generic ornamental imagery |

## Composition archetypes

Select a governing composition mechanism. A deliberate hybrid may combine mechanisms when their roles and hierarchy remain clear; do not impose an arbitrary two-job requirement.

| Archetype | Mechanism | Best fit | Guardrail |
| --- | --- | --- | --- |
| `iconic_anchor` | One dominant sign, object, face, or intervention | Civic action, culture, cover, film | Do not add a second competing hero |
| `typographic_engine` | Type itself enacts scale, rhythm, absence, interruption, or motion | Music, manifesto, title-led event | Keep functional information distinct from expressive type |
| `editorial_grid` | Grid carries the information hierarchy and measured image placement | Education, conferences, public information | Do not confuse a visible grid with visual bureaucracy |
| `conceptual_metaphor` | One original symbolic relation asks the viewer to interpret | Theatre, literature, civic and social work | Metaphor must clarify or productively deepen the subject |
| `narrative_window` | A restrained scene, crop, or point of view reveals a world | Film, event, editorial culture | Do not turn it into generic stock staging |
| `kinetic_field` | Direction, repetition, and controlled asymmetry enact pace | Music, sport, youth event | Motion must preserve title and date legibility |
| `information_beacon` | One functional datum is elevated, with secondary details grouped | Community event, alert, deadline, call to action | Do not use it for a dense legal or production-master layout |

## Historical and visual style families

Default to one primary family and a compatible material treatment. Preserve a requested deliberate hybrid when its relationships serve the same strategy. Translate the family into the listed attributes, not into a replica of a historic work or named designer.

| Style family | Transferable attributes | Strong fit | Avoid when |
| --- | --- | --- | --- |
| `art_nouveau` | sinuous contour, organic framing, decorative rhythm, stylised botanical or human silhouette | beauty, cultural heritage, elegant event | the message needs fast factual scanning |
| `art_deco` | stepped geometry, symmetry or disciplined axial tension, streamlined scale, restrained luxury | travel, fashion, premium gala, retro cinema | ornate period decoration conflicts with an urgent social message |
| `constructivist` | diagonal force, large scale shifts, geometric planes, purposeful photomontage logic, compressed headline | action, sport, music, manifesto | ideological visual cues would be inappropriate or confusing |
| `new_typography` | asymmetric information, functional hierarchy, photography and type as communication structure | exhibition, education, public information | a period label would replace actual reading decisions |
| `bauhaus` | elementary relationships of form, space, colour and typography; experimental construction within a functional task | design, exhibition, educational culture | primary-colour shapes become a decorative sticker |
| `swiss_grid` | measured grid, precise sans-serif behaviour, controlled white space, objective hierarchy, limited palette | public information, conference, design-led culture | the intended tone needs roughness, play, or handmade individuality |
| `polish_poster_school` | concise metaphor, interpretive image, type-image tension, wit, vivid but deliberate colour | theatre, film, literature, civic concept | the result would depend on direct imitation of a named artist or a painterly-surreal stereotype |
| `psychedelic` | optically active type, saturated colour tension, fluid contour, perceptual rhythm | music, youth culture, era-specific event | dense functional copy or accessibility requires neutral reading |
| `pop_reproduction` | flat spot colour, halftone logic, repetition, irony, bold framing | retail, youth activation, playful campaign | the subject requires gravity or a non-commercial tone |
| `surrealist_conceptual` | improbable but precise visual relation, altered scale, visual riddle, restrained field | art-house film, literary work, awareness campaign | the viewer needs immediate literal instruction |
| `midcentury_symbolic_cinema` | one reductive sign, title-image interlock, decisive negative space, graphic silhouette | film, podcast, author event, cover | the user needs an ensemble cast or factual programme at first glance |
| `illustrated_key_art` | authored scene, hierarchy between protagonists and world, genre signal, purposeful detail | fiction, games, family event, film | detailed illustration competes with compact information |
| `authorial_art_house` | interpretive image, controlled ambiguity, texture with meaning, title as a counterpoint | independent cinema, gallery, theatre | the objective is direct retail conversion or urgent public instruction |

Historical basis for these families includes documented poster developments in the V&A collections; MoMA's account of New Typography; Poster House's Swiss Grid research; Culture.pl's account of the Polish Poster School; and documented film-poster and print histories. This reference carries forward transferable design logic, not any protected artwork, artist signature, or regional stereotype.

## Material and reproduction treatments

These are visual treatments, not claims that the output was physically printed by the named process.

| Treatment | Visible cues to specify | Useful constraint |
| --- | --- | --- |
| `lithographic_colour` | flat colour separation, drawn contour, broad fields, subtle paper interaction | Use only the colours needed by the hierarchy |
| `screenprint` | opaque spot colours, deliberate overlaps, sharp shapes, sparse overprint | Limit the palette and name the purpose of each layer |
| `risograph` | uncoated-paper tactility, layered spot colours, controlled overprint, subtle registration drift | Drift is local and restrained, never a global blur or damage effect |
| `letterpress` | ink impression, direct type-image relationship, relief-like tactility, few colours | Do not use it to excuse unreadable small copy |
| `photomontage` | purposeful cut scale, structural cropping, image-text collision, clear source hierarchy | Every fragment must have a stated role |
| `collage` | material edges, selected found-form contrast, tactile assembly | Use one governing composition, never equal-weight scrap accumulation |
| `offset_reproduction` | controlled colour reproduction, selected screening, stock-aware surface | Do not turn managed reproduction into generic noise |
| `halftone_reproduction` | dot structure tied to a photographic or mass-reproduction role | Do not overlay identical dots on every surface |

## Anti-slop composition gate

Before final delivery, require all of the following:

1. The poster can state its communication goal in one sentence.
2. One visual thesis carries that goal; the hero is not a merely attractive background.
3. The necessary attention levels are intentional; a single-word poster may need only one, while a programme needs a scan path.
4. The composition explains where the required elements belong, including a type-only design without an image hero.
5. The selected style changes composition, typography, colour, and material behaviour, not only the effect stack.
6. Every decorative-looking element has a named job: hierarchy, meaning, navigation, recognition, or material evidence.
7. The complete words/form relation is message-specific. Use a substitution test on that relation; deleting the title is invalid for a typographic concept.
8. Generic smoke, particles, chrome, neon glow, cityscape, crowds, lens flare, pseudo-3D objects, random grids, and arbitrary paper texture are absent unless their job is explicit.
9. Attention roles and required status are distinct; all required metadata remains readable and decoration never impersonates information.
10. Any print look follows a named process logic rather than a generic vintage or damage filter.

A single failed core mechanism, required string or protected source property blocks acceptance. Use QA and repair (the `qa-iteration` handoff) to distinguish a local repair from a strategy rebuild. A style preference alone does not require a full rerender; a longer negative list does not repair a missing concept.

## Prompt handoff

Use the single [workflow contract](static-design-direction.md): put the composition, attention order, visual thesis and treatments in `strategy`; retain the selected `concept.lock`. Distribute the decisions through the one final prompt. Do not append a style paragraph that contradicts earlier instructions or introduce a competing field schema.
