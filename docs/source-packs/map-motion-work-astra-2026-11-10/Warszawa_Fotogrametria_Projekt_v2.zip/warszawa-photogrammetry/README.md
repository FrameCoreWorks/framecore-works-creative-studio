# Warszawa Centralna → PKiN: test prawdziwej fotogrametrii

Wersja 2 filmu z fotogrametrią: ścieżka pojawia się stopniowo za poruszającym się punktem. Wcześniejszy film z uproszczonymi bryłami pozostaje osobnym projektem.

## Co zmieniono

- Ścieżka jest ukryta podczas początkowego zbliżenia (0–5 s). W trakcie marszu (5–24 s) widoczny jest wyłącznie już przebyty odcinek, kończący się pod znacznikiem. Po dojściu do celu pozostaje pełna trasa.
- W tej korekcie wyrenderowano ponownie pierwsze 1440 klatek. Ostatnie 360 klatek (24–30 s), w których cała trasa jest już przebyta, zachowano z pierwszego renderu. Kamera i zapisane wysokości trasy pozostały takie same.

- Całą zabudowę i powierzchnię miasta zastępuje gotowy, publicznie dostępny skan fotogrametryczny. Nie wykorzystano brył z poprzedniej wersji, generowanych fasad ani nakładania zdjęć na tamte bryły.
- Źródło: **DSM_Mesh_Warsaw_SURE5_0_1_33m**, warstwa **IntegratedMesh**, OGC I3S 1.7. Model zawiera geometrię, tekstury i poziomy szczegółowości przygotowane przez źródłowego dostawcę.
- Trasa pochodzi z wcześniej poprawionej sieci pieszej OSM: 635,7078 m, chodniki, przejścia i schody. Film podaje zaokrąglone 640 m. Jest to przyspieszony lot kamery śledzącej trasę, nie nagranie z poziomu oczu.
- Wymagany eksport: 30 sekund, 1080 × 1920, 60 kl./s, H.264, **zero strumieni audio**.

## Model i ograniczenia źródła

[Strona modelu w ArcGIS](https://www.arcgis.com/home/item.html?id=0d79fce75b8e44e1936bbbe2cc440333)

[Usługa modelu](https://tiles-eu1.arcgis.com/7cCya5lpv5CmFJHv/arcgis/rest/services/DSM_Mesh_Warsaw_SURE5_0_1_33m/SceneServer)

Autorstwo / źródło wskazane w metadanych: **Warsaw University of Technology, Esri**. Opis podaje zdjęcia DMC III, pokrycie 80/80%, GSD 8 cm. Jest to parametr zdjęć wejściowych, nie gwarancja rozdzielczości każdej tekstury renderu. Element opublikowano w lutym 2023 r. Data wykonania zdjęć: **Unknown**. Model może pokazywać starszy stan zagospodarowania niż aktualna sieć piesza.

Zasięg modelu obejmuje całą trasę. Dostęp do odczytu jest publiczny i podczas testu nie wymagał klucza ani płatnego konta. Pole `licenseInfo` jest puste. **Licencja do komercyjnego filmu reklamowego: Unknown.** Ten materiał jest testem technicznym do prywatnej oceny. Publiczny dostęp do warstwy nie został uznany za licencję do reklam, odsprzedaży ani redystrybucji modelu.

Projekt nie zawiera kopii skanu ani tekstur do dalszego rozpowszechniania. `server.py` w trybie sieciowym odczytuje wskazaną usługę i sprawdza ważność odpowiedzi według `max-age` źródła. Przy korekcie v2 render korzystał wyłącznie z fragmentów modelu już zapisanych lokalnie (`MODEL_OFFLINE=1`), po przerwaniu dostępu sieciowego. Tryb lokalny nie odświeża dat danych i nie wykonuje połączeń do źródła; brakujący fragment przerywa pracę zamiast uruchamiać pobieranie. Zmiana dostępności zewnętrznej warstwy może uniemożliwić ponowny render.

Kontrola podglądów ujawniła niższą szczegółowość i miejscowe deformacje odległej zabudowy w szerokim planie. To ograniczenie dostępnego skanu i jego poziomów szczegółowości. Model nie jest współczesnym pomiarem całego miasta ani fotorealistyczną rekonstrukcją z gwarancją poprawności każdego budynku.

## Narzędzia użyte

| Narzędzie | Rola |
|---|---|
| **CesiumJS 1.147.0** | Wczytanie gotowej warstwy I3S przez `I3SDataProvider`, kamera, perspektywa, poziomy szczegółowości, trasa i znacznik |
| **ArcGIS Scene Service / I3S IntegratedMesh** | Dostarczenie istniejącego skanu Warszawy wraz z oryginalnymi teksturami |
| **OpenStreetMap i lokalny graf pieszy z poprzedniego projektu** | Przebieg trasy po chodnikach, przejściach i schodach; bez wyznaczania trasy samochodowej |
| **JavaScript / HTML / CSS** | Deterministyczna pozycja kamery i znacznika dla czasu każdej klatki, napisy |
| **Playwright 1.62.1 / Chromium 153** | Renderowanie klatek w przeglądarce i podglądy kontrolne |
| **FFmpeg 7.1.5 / ffprobe** | Kodowanie niemego MP4 i sprawdzenie parametrów pliku |
| **Python 3.12** | Odczyt metadanych, sprawdzenie pokrycia, lokalny serwer i kontrola wyniku |
| **Shapely 2.1.2** | Test zgodności zachowanej trasy z siecią pieszą OSM |
| **Node.js 24.22.1 / npm** | Uruchomienie renderera i przypięcie wersji zależności |

Muzyka, SFX, synteza audio i AI-generowane obrazy nie były częścią tego wariantu.

## Repozytoria sprawdzone

1. [CesiumGS/cesium](https://github.com/CesiumGS/cesium), Apache-2.0: **wybrane i uruchomione**. Obsługuje również I3S, dlatego pasuje bezpośrednio do znalezionego skanu.
2. [NASA-AMMOS/3DTilesRendererJS](https://github.com/NASA-AMMOS/3DTilesRendererJS), Apache-2.0: alternatywa do źródeł 3D Tiles w scenach Three.js. Nie użyto w tym renderze.
3. [CesiumGS/cesium-unreal](https://github.com/CesiumGS/cesium-unreal): alternatywa dla środowiska Unreal Engine. Nie instalowano i nie użyto.

Są to silniki odczytu i wyświetlania danych, a nie biblioteki gotowych modeli wszystkich miast. Licencja silnika nie obejmuje automatycznie licencji danych mapowych.

Sprawdzono także oficjalny skorowidz modeli mesh GUGiK. Zapytanie WFS dla obszaru tej trasy zwróciło `numberMatched="0"`. Dane LoD1/LoD2 oraz ortofotomapa nie zastępują fotogrametrycznego modelu elewacji i nie zostały użyte do udawania takiego modelu.

## Kontrola

- Test poprzednio poprawionej trasy pieszej: PASS, 0,0 m poza siecią pieszą przy tolerancji 0,6 m. To test zgodności z danymi OSM, nie terenowa kontrola bieżących remontów.
- Podgląd gotowego modelu w Cesium: potwierdzony; widoczne rzeczywiste fasady, dachy i otoczenie PKiN.
- Kontrola końcowa: PASS. 30,000 s; 1080 × 1920; 60 kl./s; 1800 klatek; H.264; 0 strumieni audio. Pełne dekodowanie bez błędu, brak wykrytych czarnych odcinków i zatrzymań obrazu dłuższych niż 0,5 s. Raport: `video-qa.json`.
- Sprawdzono wybrane kadry pobrane z finalnego MP4, w tym okolice przejścia kamery przy 24. sekundzie. Automatyczne kontrole nie mierzą kompletności ani aktualności skanu miasta.
- Pierwszy zapis 1800 klatek w tym środowisku trwał 34 min 30 s, bez wstępnego wczytania modelu i końcowego kodowania. To wynik tego testu, nie gwarantowany czas przyszłych renderów.

## Uruchomienie

Zainstalować zależności z `package-lock.json`, zapewnić FFmpeg w PATH. `npm run render` uruchamia lokalny serwer, renderuje film, dodaje widoczne oznaczenie źródła trasy i wykonuje kontrolę MP4; `REVIEW_ONLY=1 node render.cjs` przygotowuje kadry kontrolne. Wysokości trasy zostały wcześniej próbkowane z gotowego skanu i zachowane w `data/route-height-audit.json`, aby kolejne poprawki utrzymały tę samą kamerę i geometrię. Pod zadaszeniami wysokość chodnika jest szacowana z sąsiednich odkrytych fragmentów, aby linia nie wspinała się na dach. Wysokość znacznika nie jest pomiarem geodezyjnym. Program pobiera wyłącznie fragmenty publicznej warstwy potrzebne kamerze. Pierwsze wczytanie może trwać kilka minut. Skrypt czeka na wczytanie fragmentów przed zapisem klatek.

Pamięć podręczna skanu oraz `node_modules` nie należą do paczki projektu. Nie wykonano publikacji, deployu ani modyfikacji stałego pluginu Toolbox.

Pełny `npm run render` odtwarza wszystkie 1800 klatek z aktualną animacją ścieżki i nie wymaga wcześniejszego MP4. Wariant częściowy: `RENDER_FRAMES=1440 node render.cjs`, a następnie `python3 finalize.py --tail-from review/picture-before-route-credit.mp4`. Ten drugi sposób wymaga oryginalnego renderu bez dodatkowej linii oznaczenia OSM.

Zapis nowych 1440 klatek (24 s) w ukończonej korekcie v2 trwał 893.45 s. Czas nie obejmuje przygotowania modelu, wcześniejszej nieudanej próby, końcowego połączenia z zachowanym finałem ani kontroli pliku.

## Uwaga techniczna dla kolejnych poprawek

Narastająca linia korzysta z synchronicznej `Cesium.PolylineCollection`. Zmiana tablicy pozycji polilinii typu Entity w każdej klatce uruchamiała asynchroniczną przebudowę geometrii: podgląd po oczekiwaniu był poprawny, ale podczas ciągłego zapisu znikały linia i znacznik. Kontrola tego efektu musi obejmować serię następujących po sobie klatek i kadry z zakodowanego MP4, nie tylko pojedyncze podglądy po wczytaniu sceny.
