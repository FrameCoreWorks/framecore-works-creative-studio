"""Add source attribution. Optionally retain the unchanged final six seconds."""
from pathlib import Path
import argparse
import json
import subprocess

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--tail-from', type=Path, help='Original uncredited 1800-frame render; reuse frames 1440–1799')
args = parser.parse_args()
raw = root / 'review/route-reveal-raw.mp4'
video = root / 'delivery/Warszawa_Centralna_PKiN_Fotogrametria_v2_sciezka_za_punktem.mp4'
credit = root / 'data/route-credit.txt'
credit.write_text('Trasa: © OpenStreetMap contributors', encoding='utf-8')

def check_source(path, frames):
    meta = json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(path)]))
    streams = [s for s in meta['streams'] if s['codec_type'] == 'video']
    assert len(streams) == 1
    stream = streams[0]
    assert (stream['width'],stream['height']) == (1080,1920)
    assert stream['r_frame_rate'] == '60/1' and int(stream['nb_frames']) == frames

check_source(raw, 1440 if args.tail_from else 1800)
draw = f'drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:textfile={credit}:fontsize=20:fontcolor=white:x=16:y=h-78:box=1:boxcolor=black@0.60:boxborderw=6'
cmd = ['ffmpeg','-y','-v','error','-i',str(raw)]
if args.tail_from:
    check_source(args.tail_from,1800)
    cmd += ['-i',str(args.tail_from),'-filter_complex',
            '[0:v]trim=end_frame=1440,setpts=PTS-STARTPTS[prefix];'
            '[1:v]trim=start_frame=1440:end_frame=1800,setpts=PTS-STARTPTS[tail];'
            f'[prefix][tail]concat=n=2:v=1:a=0,{draw}[v]', '-map','[v]']
else:
    cmd += ['-map','0:v:0','-vf',draw]
cmd += ['-an','-r','60','-c:v','libx264','-preset','fast','-crf','16','-pix_fmt','yuv420p',
        '-color_range','tv','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709',
        '-movflags','+faststart',str(video)]
subprocess.run(cmd,check=True)
print(video)
