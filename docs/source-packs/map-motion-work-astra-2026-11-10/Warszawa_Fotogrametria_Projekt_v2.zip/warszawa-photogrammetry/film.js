/* Genuine source photogrammetry. No OSM extrusion, facade generation or retexturing. */
const C = Cesium;
C.Ion.defaultAccessToken = '';
C.CreditDisplay.cesiumCredit=new C.Credit('CesiumJS',true);
const viewer = new C.Viewer('scene', {
  baseLayer:false,geocoder:false,baseLayerPicker:false,animation:false,timeline:false,
  sceneModePicker:false,navigationHelpButton:false,homeButton:false,fullscreenButton:false,
  selectionIndicator:false,infoBox:false,shouldAnimate:false,
  contextOptions:{webgl:{alpha:false,antialias:true,preserveDrawingBuffer:true}},
  useBrowserRecommendedResolution:false
});
window.viewer=viewer;
viewer.scene.globe.show=false;
viewer.scene.skyAtmosphere.show=false;
viewer.scene.skyBox.show=false;
viewer.scene.sun.show=false;
viewer.scene.moon.show=false;
viewer.scene.backgroundColor=C.Color.fromCssColorString('#222e37');
viewer.scene.fog.enabled=false;
viewer.scene.postProcessStages.fxaa.enabled=true;
viewer.resolutionScale=1;
viewer.camera.frustum.fov=C.Math.toRadians(48);
viewer.scene.screenSpaceCameraController.enableInputs=false;
viewer.creditDisplay.addStaticCredit(new C.Credit('Model: Warsaw University of Technology / Esri • test techniczny',true));
window.errors=[];
viewer.scene.renderError.addEventListener((_,e)=>window.errors.push(String(e)));

(async()=>{
 const provider=await C.I3SDataProvider.fromUrl('/mesh/layers/0',{
   calculateNormals:false,
   cesium3dTilesetOptions:{maximumScreenSpaceError:8,skipLevelOfDetail:false,dynamicScreenSpaceError:false,cacheBytes:768*1024*1024,maximumCacheOverflowBytes:512*1024*1024}
 });
 viewer.scene.primitives.add(provider);window.provider=provider;
 const route=(await (await fetch('/data/route.json')).json()).routes[0];
 const coords=route.geometry.coordinates;
 const distances=[0];
 for(let i=1;i<coords.length;i++){
   const a=C.Cartographic.fromDegrees(...coords[i-1]),b=C.Cartographic.fromDegrees(...coords[i]);
   distances.push(distances[i-1]+new C.EllipsoidGeodesic(a,b).surfaceDistance);
 }
 const total=distances.at(-1);
 const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
 const smooth=v=>{v=clamp(v);return v*v*(3-2*v)};
 const mix=(a,b,v)=>a+(b-a)*v;
 function along(u){
  const d=clamp(u)*total;let i=1;
  while(i<distances.length-1 && distances[i]<d)i++;
  const f=(d-distances[i-1])/(distances[i]-distances[i-1]);
  return [mix(coords[i-1][0],coords[i][0],f),mix(coords[i-1][1],coords[i][1],f)];
 }
 let heights=coords.map(()=>112);
 const linePositions=coords.map(p=>C.Cartesian3.fromDegrees(p[0],p[1],112));
 // A synchronous PolylineCollection avoids asynchronous Entity geometry
 // rebuilding on every captured frame, which can hide the route and marker.
 const routeLines=viewer.scene.primitives.add(new C.PolylineCollection());
 const line=routeLines.add({show:false,positions:[],width:5,material:C.Material.fromType('Color',{color:C.Color.fromCssColorString('#f4e769')})});
 const marker=viewer.entities.add({position:linePositions[0],point:{pixelSize:16,color:C.Color.WHITE,outlineColor:C.Color.fromCssColorString('#263e44'),outlineWidth:4,disableDepthTestDistance:0}});
 const start=coords[0],end=coords.at(-1);
 const title=document.querySelector('#title');
 function groundAt(u){let i=1,d=clamp(u)*total;while(i<distances.length-1&&distances[i]<d)i++;return mix(heights[i-1],heights[i],clamp((d-distances[i-1])/(distances[i]-distances[i-1])))}
 window.applyRouteHeights=samples=>{
  if(samples.length!==coords.length||samples.some((s,i)=>s.index!==i||!Number.isFinite(s.height)))throw new Error('Invalid stored route heights');
  heights=samples.map(s=>s.height);
  window.routeHeightAudit=samples;
  return samples;
 };
 window.prepareRouteHeights=()=>{
  const raw=coords.map(([lon,lat],i)=>{
   const center=viewer.scene.sampleHeight(C.Cartographic.fromDegrees(lon,lat));
   const around=[];
   for(const [dx,dy] of [[-18,0],[18,0],[0,-18],[0,18],[-12,-12],[12,12]]){
    const h=viewer.scene.sampleHeight(C.Cartographic.fromDegrees(lon+dx/(111320*Math.cos(lat*Math.PI/180)),lat+dy/111320));
    if(Number.isFinite(h)&&h>50&&h<250)around.push(h);
   }
   around.sort((a,b)=>a-b);
   return {index:i,center:Number.isFinite(center)?center:null,around};
  });
  const all=raw.flatMap(x=>x.around).sort((a,b)=>a-b);
  if(all.length<coords.length)throw new Error('Insufficient sampled ground heights');
  const regionalGround=all[Math.floor(all.length*.2)];
  const samples=raw.map(({index,center,around})=>{
   const candidates=around.filter(h=>Math.abs(h-regionalGround)<8);
   const ground=candidates.length?candidates[Math.floor((candidates.length-1)*.2)]:regionalGround;
   const covered=Number.isFinite(center)&&center>ground+5;
   const height=Number.isFinite(center)&&!covered?center:ground;
   return {index,center,ground,height:height+.35,covered};
  });
  return window.applyRouteHeights(samples);
 };
 window.draw=async(t)=>{
  let p,heading,pitch,range,h=112;
  // Smooth acceleration/deceleration at both ends, with stable linear cruise.
  const u=clamp((t-5)/19),r=.08;
  const progress=u<r?u*u/(2*r*(1-r)):u>1-r?1-(1-u)*(1-u)/(2*r*(1-r)):(u-r/2)/(1-r);
  if(t<5){
   const k=smooth(t/5);p=[mix(21.0057,start[0],k),mix(52.2307,start[1],k)];heading=mix(25,36,k);pitch=-53;range=mix(1050,330,k);h=mix(groundAt(.5)+33,groundAt(0),k);
  }else if(t<24){
   const span=.018*Math.sin(Math.PI*progress),a=along(progress-span),b=along(progress),c=along(progress+span);
   p=[(a[0]+2*b[0]+c[0])/4,(a[1]+2*b[1]+c[1])/4];heading=mix(36,-40,smooth(progress));pitch=-53;range=mix(330,370,smooth(progress));h=groundAt(progress);
  }else{
   const k=smooth((t-24)/6);p=[mix(end[0],21.0060,k),mix(end[1],52.2318,k)];heading=mix(-40,12,k);pitch=mix(-53,-40,k);range=mix(370,940,k);h=mix(groundAt(1),groundAt(1)+78,k);
  }
  viewer.camera.lookAt(C.Cartesian3.fromDegrees(...p,h),new C.HeadingPitchRange(C.Math.toRadians(heading),C.Math.toRadians(pitch),range));
  const point=along(progress),height=groundAt(progress);
  // Reveal only the already-walked prefix, with the live endpoint on the
  // same segment and at the same progress as the moving marker.
  const walked=progress*total;
  let next=1;
  while(next<coords.length-1&&distances[next]<walked)next++;
  const visible=coords.slice(0,next).map((p,i)=>C.Cartesian3.fromDegrees(...p,heights[i]));
  visible.push(C.Cartesian3.fromDegrees(...point,height));
  line.show=progress>0;
  line.positions=progress>0?visible:[];
  window.routeReveal={progress,visible:line.show,vertices:progress>0?visible.length:0,totalVertices:coords.length,endpoint:point,walkedMeters:walked};
  marker.position=C.Cartesian3.fromDegrees(...point,height+2);
  title.style.opacity=t<3?1:t<5?1-smooth((t-3)/2):t>26?smooth((t-26)/2):0;
  title.innerHTML=t>25?'<small>NA MIEJSCU</small>Pałac Kultury<br>i Nauki<span>Spacer z Warszawy Centralnej</span>':'<small>WARSZAWA • FOTOGRAMETRIA</small>Centralny → PKiN<span>640 m pieszo</span>';
  if(window.recording){viewer.render();}
  else {await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));}
  return window.inspect();
 };
 const target=C.Cartesian3.fromDegrees(21.0058,52.2317,170);
 viewer.camera.lookAt(target,new C.HeadingPitchRange(C.Math.toRadians(-35),C.Math.toRadians(-35),950));
 window.ready=true;
 window.inspect=()=>({loaded:provider.layers.every(l=>l.tileset.tilesLoaded),layers:provider.layers.length,errors:window.errors,reveal:window.routeReveal,statistics:provider.layers.map(l=>({selected:l.tileset.statistics?.selected,requests:l.tileset.statistics?.numberOfPendingRequests}))});
})().catch(e=>{window.errors.push(String(e));console.error(e)});
