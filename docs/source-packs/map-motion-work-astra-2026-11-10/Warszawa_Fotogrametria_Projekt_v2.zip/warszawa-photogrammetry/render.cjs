const path=require('path');
const resolveRuntime=name=>require.resolve(name,{paths:[__dirname,path.resolve(__dirname,'../jakobczak-map-motion')]});
const {chromium}=require(resolveRuntime('playwright'));
const fs=require('fs'),{spawn}=require('child_process'),{once}=require('events');
for(const dir of ['review','delivery'])fs.mkdirSync(path.join(__dirname,dir),{recursive:true});
const server=spawn('python3',['-u','server.py'],{stdio:['ignore','pipe','inherit']});
let browser,encoder;
(async()=>{
 await new Promise((resolve,reject)=>{server.stdout.once('data',resolve);server.once('error',reject)});
 server.stdout.on('data',d=>process.stdout.write(d));
 const shell=(await import(resolveRuntime('@sparticuz/chromium'))).default;
 browser=await chromium.launch({executablePath:await shell.executablePath(),args:[...shell.args,'--enable-unsafe-swiftshader'],headless:true});
 const page=await browser.newPage({viewport:{width:1080,height:1920},deviceScaleFactor:1});
 let slots=12;const queue=[];
 async function acquire(){if(slots>0){slots--;return}await new Promise(r=>queue.push(r))}
 function release(){if(queue.length)queue.shift()();else slots++}
 // APIRequestContext avoids Chromium's six HTTP/1 connections queue. The proxy
 // caps external requests at 12 and honors source cache lifetimes.
 await page.route('http://127.0.0.1:8767/mesh/**',async route=>{
  pending++;lastRequest=Date.now();
  await acquire();
  let response;
  try {
   response=await page.request.get(route.request().url(),{timeout:90000,maxRetries:2});
   if(!response.ok())throw new Error(`Mesh response ${response.status()}: ${route.request().url()}`);
   await route.fulfill({response});
  }
  catch(e){errors.push(String(e));console.log('TRANSFER_ERROR',String(e));await route.abort();}
  finally {await response?.dispose();release();pending--;lastRequest=Date.now()}
 });
 const errors=[];let pending=0,lastRequest=Date.now();
 page.on('pageerror',e=>{errors.push(e.message);console.log('ERROR',e.message)});
 page.on('response',r=>{if(r.status()>=400){errors.push(`${r.status()} ${r.url()}`);console.log('HTTP',r.status(),r.url())}});
 await page.goto('http://127.0.0.1:8767');
 await page.waitForFunction(()=>window.ready,{timeout:120000});
 await page.evaluate(()=>{window.viewer.useDefaultRenderLoop=false;window.recording=true});
 async function settle(ms=1200){
  const start=Date.now();let lastLog=start;
  while(true){
   const s=await page.evaluate(()=>{if(window.recording)window.viewer.render();return {loaded:window.inspect().loaded,triangles:window.provider.layers[0].tileset.statistics.numberOfTrianglesSelected,errors:window.errors}});
   if(s.errors.length)throw new Error(JSON.stringify(s.errors));
   if(pending===0&&Date.now()-lastRequest>ms&&s.loaded&&s.triangles>10000)return s;
   if(Date.now()-start>600000)throw new Error('Mesh did not settle: '+JSON.stringify({pending,s}));
   if(Date.now()-lastLog>15000){console.log('LOADING',JSON.stringify({pending,...s}));await page.screenshot({path:'review/loading.jpg',type:'jpeg',quality:85});lastLog=Date.now()}
   await page.waitForTimeout(250);
  }
 }
 const priming=[0,5,10,15,20,24,29.99];
 for(const t of priming){
  console.log('PRIME',t);await page.evaluate(t=>window.draw(t),t);const s=await settle();
  await page.screenshot({path:`review/frame-${String(t).replace('.','_')}.jpg`,type:'jpeg',quality:96});
  console.log('PRIMED',t,JSON.stringify(s));
 }
 const storedHeights=JSON.parse(fs.readFileSync('data/route-height-audit.json','utf8'));
 const heights=await page.evaluate(samples=>window.applyRouteHeights(samples),storedHeights);
 fs.writeFileSync('review/route-height-audit.json',JSON.stringify(heights,null,2));
 const revealChecks=[];
 for(const t of priming){
  const state=await page.evaluate(t=>window.draw(t),t);await settle(300);
  if(t<=5&&(state.reveal.visible||state.reveal.vertices!==0))throw new Error('Route visible before marker starts');
  if(t>5&&t<24&&(!state.reveal.visible||state.reveal.progress>=1))throw new Error('Invalid partial route');
  if(t>=24&&state.reveal.progress!==1)throw new Error('Route incomplete at arrival');
  revealChecks.push({time:t,...state.reveal});
  await page.screenshot({path:`review/frame-${String(t).replace('.','_')}.jpg`,type:'jpeg',quality:96});
 }
 fs.writeFileSync('review/route-reveal-check.json',JSON.stringify(revealChecks,null,2));
 if(process.env.REVIEW_ONLY==='1'){
  fs.writeFileSync('review/render-review.json',JSON.stringify({errors,priming,browser:await browser.version()},null,2));
  await browser.close();server.kill();return;
 }
 if(process.env.REVEAL_PREFLIGHT==='1'){
  fs.rmSync('review/reveal-preflight-approved',{force:true});
  for(let f=0;f<18;f++){
   const state=await page.evaluate(t=>window.draw(t),10+f/60);
   if(pending>0||!state.loaded)await settle(200);
   const shot=await page.screenshot({type:'jpeg',quality:97});
   if(f===17)fs.writeFileSync('review/reveal-preflight-final.jpg',shot);
  }
  console.log('PREFLIGHT_READY review/reveal-preflight-final.jpg');
  const since=Date.now();
  while(!fs.existsSync('review/reveal-preflight-approved')){
   if(Date.now()-since>600000)throw new Error('Preflight review timed out');
   await page.waitForTimeout(500);
  }
 }
 const fps=60,frames=Number(process.env.RENDER_FRAMES||1800),dest=process.env.RENDER_OUTPUT||'review/route-reveal-raw.mp4';
 if(!Number.isInteger(frames)||frames<1||frames>1800)throw new Error('Invalid render frame count');
 await page.evaluate(()=>{window.viewer.useDefaultRenderLoop=false;window.recording=true});
 encoder=spawn('ffmpeg',['-y','-hide_banner','-loglevel','warning','-f','image2pipe','-framerate',String(fps),'-vcodec','mjpeg','-i','pipe:0','-vf','scale=1080:1920:flags=lanczos:in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709','-color_range','tv','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',dest],{stdio:['pipe','ignore','pipe']});
 let stderr='';encoder.stderr.on('data',d=>stderr+=d.toString());const done=once(encoder,'close');
 const start=Date.now(),stats=[];
 for(let f=0;f<frames;f++){
  const state=await page.evaluate(t=>window.draw(t),f/fps);
  if(pending>0||!state.loaded)await settle(200);
  if(errors.length)throw new Error(JSON.stringify(errors));
  const shot=await page.screenshot({type:'jpeg',quality:97});
  if(!encoder.stdin.write(shot))await once(encoder.stdin,'drain');
  if(f%60===0){const stat={frame:f,total:frames,seconds:(Date.now()-start)/1000};stats.push(stat);console.log(JSON.stringify(stat))}
 }
 encoder.stdin.end();const [code]=await done;if(code)throw new Error(stderr);
 fs.writeFileSync(dest+'.json',JSON.stringify({fps,frames,width:1080,height:1920,audio:false,errors,stats,elapsed_seconds:(Date.now()-start)/1000,cesium:'1.147.0',browser:await browser.version(),stderr},null,2));
 console.log('COMPLETE',dest);await browser.close();server.kill();
})().catch(async e=>{console.error(e);encoder?.kill();await browser?.close();server.kill();process.exitCode=1});
