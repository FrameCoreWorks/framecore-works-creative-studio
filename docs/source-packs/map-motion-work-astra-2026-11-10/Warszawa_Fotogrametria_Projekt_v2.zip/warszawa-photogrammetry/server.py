from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.request import Request, urlopen
from pathlib import Path
import gzip, threading, time, os, hashlib, json, re

ROOT = Path(__file__).resolve().parent
REMOTE = 'https://tiles-eu1.arcgis.com/7cCya5lpv5CmFJHv/arcgis/rest/services/DSM_Mesh_Warsaw_SURE5_0_1_33m/SceneServer/'
cache = {}
lock = threading.Lock()
limit = threading.Semaphore(12)
SESSION = Path('/tmp/framecore-warsaw-photogrammetry-cache')
SESSION.mkdir(exist_ok=True)
OFFLINE = os.environ.get('MODEL_OFFLINE') == '1'

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self):
        if not self.path.startswith('/mesh/'):
            return super().do_GET()
        suffix = self.path[len('/mesh/'):]
        if '..' in suffix or suffix.startswith('/'):
            self.send_error(400); return
        with lock:
            hit = cache.get(suffix)
        key = hashlib.sha256(suffix.encode()).hexdigest()
        meta = SESSION / (key + '.json')
        blob = SESSION / (key + '.bin')
        if hit is None and meta.exists() and blob.exists():
            info = json.loads(meta.read_text())
            # Offline mode reads only project assets already obtained earlier;
            # it never attempts a source connection or refreshes their timestamps.
            if OFFLINE or info['expires'] > time.time(): hit = (blob.read_bytes(),info['mime'])
        if hit is None and OFFLINE:
            print('OFFLINE_MISS', suffix, flush=True)
            self.send_error(409, 'Model fragment not available locally'); return
        if hit is None:
            try:
                with limit, urlopen(Request(REMOTE + suffix, headers={'User-Agent':'FrameCoreWorks-MapMotion/1.0'}), timeout=45) as r:
                    data = r.read()
                    if data[:2] == b'\x1f\x8b': data = gzip.decompress(data)
                    mime = r.headers.get('Content-Type','application/octet-stream')
                    ttl = re.search(r'(?<!s-)max-age=(\d+)',r.headers.get('Cache-Control',''))
                    # Temporary in-memory request reuse for this viewing session only.
                    hit = (data, mime)
                    if ttl:
                        blob.write_bytes(data)
                        meta.write_text(json.dumps({'expires':time.time()+max(0,int(ttl[1])-int(r.headers.get('Age','0'))),'mime':mime}))
                with lock: cache[suffix] = hit
            except Exception as e:
                print('PROXY_ERROR', suffix, str(e), flush=True)
                self.send_error(502); return
        data,mime = hit
        self.send_response(200)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(data)))
        self.end_headers()
        try: self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError): pass

os.chdir(ROOT)
ThreadingHTTPServer.request_queue_size=128
print('Serving http://127.0.0.1:8767',flush=True)
ThreadingHTTPServer(('127.0.0.1',8767),Handler).serve_forever()
