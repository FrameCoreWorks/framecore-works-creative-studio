from pathlib import Path
import json, subprocess, hashlib

root=Path(__file__).resolve().parent
video=root/'delivery/Warszawa_Centralna_PKiN_Fotogrametria_v2_sciezka_za_punktem.mp4'
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)]))
streams=meta['streams']
v=[x for x in streams if x['codec_type']=='video']
a=[x for x in streams if x['codec_type']=='audio']
assert len(v)==1 and len(a)==0, 'The requested deliverable must contain one video stream and NO audio stream.'
s=v[0]
assert (s['width'],s['height'])==(1080,1920)
assert s['r_frame_rate']=='60/1'
assert int(s['nb_read_frames'])==1800
assert abs(float(meta['format']['duration'])-30)<.02
assert s['codec_name']=='h264' and s['pix_fmt']=='yuv420p'
scan=subprocess.run(['ffmpeg','-hide_banner','-nostats','-v','info','-xerror','-i',str(video),'-vf','blackdetect=d=0.05:pix_th=0.05:pic_th=0.98,freezedetect=n=-50dB:d=0.5','-an','-f','null','-'],check=True,capture_output=True,text=True)
alerts=[line for line in scan.stderr.splitlines() if 'black_start:' in line or 'lavfi.freezedetect.' in line]
report={'passed':not alerts,'duration_s':float(meta['format']['duration']),'width':1080,'height':1920,'fps':60,'frames':1800,'audio_streams':0,'decode':'PASS','black_or_frozen_interval_alerts':alerts,'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'file_size_bytes':video.stat().st_size,'limitations':['Source imagery capture date Unknown','Source commercial-video license Unknown','Walking route follows OSM foot network, not a real-time ground survey']}
(root/'delivery/video-qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
