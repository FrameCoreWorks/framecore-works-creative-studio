from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
dest=root/'delivery/Warszawa_Fotogrametria_Projekt_v2.zip'
files=['index.html','film.js','render.cjs','server.py','finalize.py','qa.py','package_project.py','package.json','package-lock.json','README.md']
files += [str(p.relative_to(root)) for p in (root/'data').glob('*')]
files += ['delivery/video-qa.json']
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for name in files:
  path=root/name
  if not path.is_file(): raise FileNotFoundError(path)
  z.write(path,'warszawa-photogrammetry/'+name)
print(dest,dest.stat().st_size)
