---
name: delivery-documentation
description: "Package accepted work for handoff: final files, prompt specs, captions, print/DTP and export notes with actual file and QA status; client handoff letter and acceptance protocol. Not for judging quality or for the file inventory itself (Asset Manifest)."
---

# Useful handoff

For account-free variants, batches and document review, apply [the shared handoff method](../pipeline-core/references/account-free-creative-production.md). Record source/output revisions, sample versus full-batch coverage, accepted recipes, exceptions and real exports; separate author instructions from technical handoff when needed. A written recipe or annotation table is not a modified media/document file.

Before final delivery of a substantive authored, revised or generated creative artifact, automatically apply [output review](../pipeline-core/references/loop-protocol.md#automatic-output-review). Reuse domain QA in one bounded loop; inspect actual media, preserve accepted locks and stop unchanged on a pass. This does not run for greetings, menus or onboarding questions. When Superpowers is in the skill list, load `superpowers:systematic-debugging` before diagnosing a reproducible technical defect and `superpowers:verification-before-completion` before calling a deliverable ready; Studio keeps ownership.

Read [production and delivery](references/production-and-delivery.md). Return the actual requested artifact plus the minimum information the next operator needs.

Apply the conditional [public research gate](../research-evidence/SKILL.md) before production advice or claims about changing channel, accessibility, or print requirements; those requirements trigger it. Prefer official specifications. If the handoff is purely a record of already verified facts, do not invent a new spec or imply one was rechecked.

Distinguish prompt, concept raster, reviewed digital raster and production master. State verified properties separately from assumptions and remaining checks. Do not equate a filename extension with editable vectors, transparency, valid QR code or print readiness.

For a file going to a printer, follow [print-ready PDF](references/print-ready-pdf.md): get the printer's specification, set trim and bleed boxes and the output intent, run the preflight where it can run, and report the profile, the checks and what the printer still has to confirm.

For audio/video, distinguish a script/cue sheet/export specification from actual media, inspected ranges and a verified export. Use the audiovisual section of the reference. Record requested, verified and unknown properties separately; never fill missing FPS, codec, sample rate, loudness, dimensions, duration, channels or caption timing with defaults. Audio Production owns audio triage; Video Prompt owns video and audiovisual review, except a rendered motion video with its contract to the Motion Graphics. Their evidence scope travels with the handoff.

Carry exact copy, reference roles, concept invariants, format, safe zones and review status. DTP notes identify unknown bleed/profile/font/dieline requirements instead of inventing them. Do not silently shorten mandatory text.

For campaign delivery, list actual variants and changed layout rules, not merely exported filenames. For long tasks, provide a compact resume sheet and unresolved decisions. Do not promise persistent memory, calendars or live project management.

Honor the host's storage contract for requested files. External upload or publication is a separate operation whose scope must be authorized; preserve authorization already granted and ask only when a material scope or host requirement remains unresolved. Do not fabricate download links, filenames, versions or a completed archive. A technical validator is not a visual, listening or synchronization acceptance test.

## Brand guide file

Where Python with Pillow runs, lay out the approved brand kit as a guide with `scripts/brand_guide.py brand-kit.json --logo-dir logo/ --language pl --out-dir guide/`: cover, logo versions with clear space and proposed minimum size, colours with HEX, RGB and WCAG contrast (CMYK only from the printer's conversion), type samples in the named fonts, voice and claims, and the kit's own rules, as PNG pages and one PDF. Unfilled fields stop it unless the guide is marked as a draft; missing logos and fonts are printed as missing.

For a client whose website or app is built by a coding agent, add the brand kit as DESIGN.md with [`design_md.py`](../pipeline-core/assets/design-md/README.md) (export; `import` reads a client's DESIGN.md into a kit).

## Client handoff

For work delivered to a client, follow [client handoff](references/client-handoff.md): files grouped by use with sortable names, a contents list, fonts and licences, the [handoff letter](assets/handoff-letter.pl.md) with the agreed rights and a plain AI-assistance line when generative tools made part of the work, and written acceptance or the [acceptance protocol](assets/acceptance-protocol.pl.md). Afterwards, a [case study](assets/case-study.template.md) only with the client's consent and the client's own figures.

## Applied practice

For classroom materials and teacher documents, use the [teacher profile](../workflow-orchestrator/references/teacher-workflow.md) and optional [Teacher Pack](../workflow-orchestrator/assets/teacher-studio/lesson-pack.template.md). Deliver complete requested content, keeping student pages, teacher instructions and answer keys distinct. Use genuinely available document/presentation tools for requested files; inspect actual page/slide breaks, glyphs, overflow and content/key consistency before claiming export readiness. Text, slide content, a saved PDF/PPTX and classroom use have separate evidence states. Preserve factual record boundaries and do not invent file links, attendance, outcomes or pupil data.

For a Logo Guide, Identity Guide or identity file package, use the [brand identity profile](../workflow-orchestrator/references/brand-identity-workflow.md) and its [Brand Identity Pack](../workflow-orchestrator/assets/brand-identity.template.md). Package the selected strategy/logo/system revisions, actual requested applications and inspected files. Keep logo-guide scope distinct from a full identity guide. Verify actual document exports and any claimed vector master; record concept, reviewed digital asset and remaining production work separately. Preserve font/rights evidence and source dependencies rather than inferring readiness from filenames.

For related assets, masters, variants, changed sources or resumable delivery, use [asset lifecycle and dependencies](references/asset-lifecycle-and-dependencies.md), the [blank manifest](assets/project-manifest.template.json) and [fictional worked example](assets/project-manifest.example.json). The optional [manifest helper](scripts/asset_manifest.py) checks declared consistency and change impact; it never inspects, uploads or modifies media.

## Integrated workflow contracts

Use [the integrated workflow-kit method](kit/method.md) for this owner’s artifact fields, bounded review and downstream handoffs. Read [Studio integration authority](../pipeline-core/references/studio-integration-policy.md) for precedence and the single active route. Preserve this owner’s domain craft and the user’s requested stage.

For a publishing bundle, use the dated [platform delivery card](references/production-and-delivery.md#platform-delivery-card); preparation and publication have separate evidence.
