import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {isDeepStrictEqual} from 'node:util';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {validateMotionToolkit} from './validate-motion-toolkit.mjs';
import {validateMotionQuality} from './validate-motion-quality.mjs';
import {validateWorkflowKit} from './validate-workflow-kit.mjs';
import {loadEffectiveEvals} from './load-effective-evals.mjs';
import {validateLearningMode} from './validate-learning-mode.mjs';
import {validateQualityMethods} from './validate-quality-methods.mjs';
import {validateCampaignWorkflow} from './validate-campaign-workflow.mjs';
import {validatePresentation} from './validate-presentation.mjs';

const expectedOwnerCount = 37;
const criticalIds = ['research_conditional_triggers', 'research_privacy', 'untrusted_sources', 'research_not_execution', 'research_failure_honesty', 'prompt_only', 'handoff_locks', 'actual_output_review', 'host_model_honesty'];
const webStates = new Set(['available_read_only', 'prohibited_by_user', 'unavailable', 'blocked', 'timeout', 'error']);
const researchTriggers = new Set(['named_tool_or_model', 'platform_requirements', 'public_claim', 'capability_claim', 'reference_or_verification_request', 'real_world_subject']);

function anchors(text) {
  const out = new Set(), occurrences = new Map();
  let fence;
  for (const line of text.split(/\r?\n/)) {
    const token = line.match(/^\s*(`{3,}|~{3,})/)?.[1];
    if (token) { if (!fence) fence = token[0]; else if (fence === token[0]) fence = undefined; continue; }
    if (fence) continue;
    const heading = line.match(/^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/)?.[1];
    if (!heading) continue;
    const slug = heading.replace(/<[^>]*>/g, '').replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, '').trim().replace(/\s/g, '-'); // GitHub's slug: each space a hyphen, runs kept
    const count = occurrences.get(slug) ?? 0; occurrences.set(slug, count + 1); out.add(count ? slug + '-' + count : slug);
  }
  return out;
}

// Hosts parse SKILL.md frontmatter as YAML: a plain scalar must not contain ': ' or ' #' or start with an indicator,
// and a quoted one must close its quotes without stray inner quotes.
function yamlScalarSafe(value) {
  if (value.startsWith('"')) return value.length > 1 && value.endsWith('"') && !/(^|[^\\])"/.test(value.slice(1, -1));
  if (value.startsWith("'")) return value.length > 1 && value.endsWith("'") && !/'/.test(value.slice(1, -1).replaceAll("''", ''));
  return !/: |\s#/.test(value) && !/^[-?:,\[\]{}#&*!|>%@`]/.test(value);
}

export function validateStudio(root, {legacy = false} = {}) {
  const base = path.resolve(root), errors = [], warnings = [], files = [], texts = new Map();
  let descriptionTotal = 0;
  const fail = (code, detail) => errors.push({code, detail});
  const within = target => target === base || target.startsWith(base + path.sep);
  const result = () => ({status: errors.length ? 'FAIL' : 'PASS', scope: 'Structural and planned-contract checks only; not host behavior, media QA, or legacy test equivalence.', errors, warnings});
  // Reject symlinks before reading any package content. No source module is executed by canonical validation.
  function walk(directory) {
    for (const entry of fs.readdirSync(directory, {withFileTypes: true})) {
      const target = path.join(directory, entry.name), rel = path.relative(base, target);
      if (entry.isSymbolicLink()) { fail('SYMLINK', rel); continue; }
      if (entry.name.startsWith('._')) fail('SIDECAR', rel);
      if (entry.isDirectory()) walk(target); else if (entry.isFile()) files.push(rel);
    }
  }
  try {
    if (fs.lstatSync(base).isSymbolicLink()) throw new Error('Package root must not be a symlink');
    walk(base);
  } catch (error) { fail('PACKAGE_ACCESS', error.message); return result(); }
  if (errors.some(error => error.code === 'SYMLINK')) return result();
  const read = relative => {
    const target = path.resolve(base, relative);
    if (!within(target) || target === base) throw new Error('Path outside package: ' + relative);
    return fs.readFileSync(target, 'utf8');
  };
  const json = relative => {
    try { const data = JSON.parse(read(relative)); if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Expected a JSON object'); return data; }
    catch (error) { fail('JSON', relative + ': ' + error.message); return {}; }
  };
  errors.push(...validateMotionToolkit(base));
  errors.push(...validateMotionQuality(base));
  errors.push(...validateWorkflowKit(base, files));
  errors.push(...validateLearningMode(base, files));
  errors.push(...validateQualityMethods(base));
  errors.push(...validateCampaignWorkflow(base, files));
  // Contract reachability and evidence boundaries; this does not execute model QA.
  const loopProfile = 'skills/pipeline-core/references/loop-protocol.md';
  try {
    const body = read(loopProfile);
    for (const pattern of [/## Automatic output review/, /automatically run one/, /Do not wait for\s+the user to request QA/, /at most three evaluation passes/, /Honor a stricter domain budget/, /deliver the result unchanged/, /QA alone authorizes no generation/, /media outcome uninspected/, /do not stack a second loop/]) {
      if (!pattern.test(body)) fail('OUTPUT_REVIEW_POLICY', loopProfile + ': ' + pattern);
    }
  } catch (error) { fail('OUTPUT_REVIEW_POLICY', error.message); }
  for (const relative of files.filter(file => /^skills\/[^/]+\/SKILL\.md$/.test(file))) {
    const link = relative === 'skills/pipeline-core/SKILL.md' ? 'references/loop-protocol.md#automatic-output-review' : '../pipeline-core/references/loop-protocol.md#automatic-output-review';
    if (!read(relative).includes('automatically apply [output review](' + link + ')')) fail('OUTPUT_REVIEW_ENTRY', relative);
  }
  // Guard the shared method contract; these checks do not execute model reasoning.
  const reasoningPolicy = 'skills/pipeline-core/references/inference-reasoning-methods.md';
  try {
    const body = read(reasoningPolicy);
    for (const pattern of [/CQoT means \*\*Critical-Questions-of-Thought\*\*/, /## One review, conditional methods/, /up to three critical questions per pass/, /CoVe is claim verification/, /leave missing evidence Unknown/, /No method\s+or handoff resets this budget/, /Passing work stops unchanged/, /actual delegation capability and task\s+authorization exist/, /do not require a model to reveal or narrate hidden reasoning/, /do not exceed 4 distinct variants/]) {
      if (!pattern.test(body)) fail('REASONING_METHOD_POLICY', reasoningPolicy + ': ' + pattern);
    }
    if (/Concise Quality (?:Of|of) Thought/.test(body)) fail('REASONING_METHOD_POLICY', 'Conflicting CQoT expansion');
    for (const relative of ['skills/pipeline-core/SKILL.md', 'skills/workflow-orchestrator/SKILL.md', 'skills/workflow-orchestrator/kit/method.md', 'skills/output-critic-iteration/SKILL.md', 'skills/research-evidence/SKILL.md', loopProfile]) {
      if (!read(relative).includes('inference-reasoning-methods.md#one-review-conditional-methods')) fail('REASONING_METHOD_ROUTE', relative);
    }
  } catch (error) { fail('REASONING_METHOD_POLICY', error.message); }
  // Brand-profile checks guard packaged contracts, not host design or file QA.
  const brandProfile = 'skills/workflow-orchestrator/references/brand-identity-workflow.md';
  const brandPack = 'skills/workflow-orchestrator/assets/brand-identity.template.md';
  const needBrand = (relative, patterns) => {
    try {
      const body = read(relative);
      for (const pattern of patterns) if (!pattern.test(body)) fail('BRAND_IDENTITY_SOURCE', relative + ': ' + pattern);
    } catch (error) { fail('BRAND_IDENTITY_SOURCE', relative + ': ' + error.message); }
  };
  needBrand(brandProfile, [/Ask exactly one missing question per response and wait/, /Keep one Project State/, /logo-only request stays logo-only/, /\.\.\/\.\.\/marketing\/SKILL\.md/, /\.\.\/\.\.\/static-graphic-design-creator\/SKILL\.md/, /\.\.\/\.\.\/delivery-documentation\/SKILL\.md/, /brief_revision/, /strategy_revision/, /## Strategy acceptance/, /## Logo and visual-system acceptance/, /## Guide, applications and delivery acceptance/, /actual vector geometry/, /CMYK.*Unknown/, /trademark clearance/, /asset lifecycle and dependency contract/]);
  needBrand(brandPack, [/existing Project State/, /one pending question/, /strategy_revision/, /logo_revision/, /identity_guide_revision/, /actual_files/, /verified_production_master/, /remaining_Unknown/, /source_revisions/]);
  for (const owner of ['marketing', 'static-graphic-design-creator', 'brief-architect', 'delivery-documentation', 'pipeline-core', 'workflow-orchestrator']) needBrand('skills/' + owner + '/SKILL.md', [/brand-identity-workflow\.md/]);
  needBrand('skills/pipeline-core/references/workflow-blueprints.md', [/brand-identity-workflow\.md/, /logo-only request skips the unrequested stages/]);
  const portable = json('plugin.json'), compatibility = json('.codex-plugin/plugin.json'), registry = json('scripts/studio-contracts.json');
  for (const key of ['name', 'version', 'description', 'author']) if (!portable[key] || !isDeepStrictEqual(portable[key], compatibility[key])) fail('MANIFEST_IDENTITY', key);
  if (!isDeepStrictEqual(portable.keywords, compatibility.keywords)) fail('MANIFEST_IDENTITY', 'keywords');
  // Claude reads its own manifest; it must carry the same identity and version.
  const claude = files.includes('.claude-plugin/plugin.json') ? json('.claude-plugin/plugin.json') : null;
  if (!claude) fail('MANIFEST_IDENTITY', '.claude-plugin/plugin.json is missing');
  else for (const key of ['name', 'version', 'description', 'author', 'keywords']) if (!isDeepStrictEqual(portable[key], claude[key])) fail('MANIFEST_IDENTITY', 'claude ' + key);
  if (files.some(file => file.startsWith('bin/'))) fail('UNPLANNED_INTEGRATION', 'a top-level bin/ folder makes the Claude apps refuse the plugin');
  if (portable.name !== 'framecore-work-creative-studio') fail('PLUGIN_IDENTITY', String(portable.name));
  const semver = String(portable.version ?? '').match(/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/);
  if (!semver || semver[4]?.split('.').some(part => /^\d+$/.test(part) && /^0\d/.test(part))) fail('VERSION', String(portable.version));
  if (portable.$schema !== 'https://agent-plugins.org/schemas/1.0.0/plugin.schema.json') fail('MANIFEST_SCHEMA', 'Portable schema missing');
  const discovery = compatibility.skills;
  if (typeof discovery !== 'string' || path.isAbsolute(discovery) || discovery.includes('\0') || path.resolve(base, discovery) !== path.join(base, 'skills')) fail('SKILLS_PATH', String(discovery));
  const ui = portable.extensions?.['com.openai']?.interface;
  if (!ui || !isDeepStrictEqual(ui, compatibility.interface)) fail('INTERFACE', 'Portable and compatibility interfaces differ');
  if (ui?.displayName !== 'FrameCore Works Creative Studio') fail('DISPLAY_NAME', 'Unexpected display name');
  if (typeof ui?.shortDescription !== 'string' || !ui.shortDescription.trim() || [...ui.shortDescription].length > 30) fail('SHORT_DESCRIPTION', 'Listing subtitle must have one to thirty characters');
  if (!Array.isArray(ui?.defaultPrompt) || !ui.defaultPrompt.length || ui.defaultPrompt.length > 3 || ui.defaultPrompt.some(item => typeof item !== 'string' || item.length > 128)) fail('STARTERS', 'Expected one to three concise starters');
  for (const name of ['mcp.json', '.mcp.json', 'app.json', '.app.json', 'hooks.json']) if (files.includes(name)) fail('UNPLANNED_INTEGRATION', name);
  for (const key of ['mcpServers', 'apps', 'hooks']) if (key in portable || key in compatibility || key in (portable.extensions?.['com.openai'] ?? {})) fail('UNPLANNED_INTEGRATION', key);
  for (const required of ['NOTICE', 'licenses/Apache-2.0.txt']) if (!files.includes(required)) fail('PROVENANCE', required);
  const staticProvenance = json('skills/static-graphic-design-creator/source-provenance.json');
  if (staticProvenance.immutable_source_commit !== 'cbfc0160333d8605078c9a75508116b678f5af99' || staticProvenance.source_bundle_file_count !== 34 || !Array.isArray(staticProvenance.files) || staticProvenance.files.length !== 34) fail('STATIC_SOURCE_MANIFEST', 'Expected the complete pinned 34-file source bundle');
  for (const sourceFile of staticProvenance.files ?? []) {
    const relative = 'skills/static-graphic-design-creator/' + sourceFile.bundled_path;
    if (!files.includes(relative)) { fail('STATIC_SOURCE_FILE', relative); continue; }
    const digest = createHash('sha256').update(fs.readFileSync(path.join(base, relative))).digest('hex');
    if (digest !== sourceFile.sha256 || sourceFile.sha256_verified_after_transfer !== true) fail('STATIC_SOURCE_HASH', relative);
  }
  for (const relative of files.filter(file => file.endsWith('.md') && !file.startsWith('integrations/workflow-kit/upstream/'))) {
    const text = read(relative); texts.set(relative, text);
    if (relative.startsWith('skills/') && /\/Users\/|\/Volumes\/|turn\d+(?:search|view)\d+|\[TODO:/i.test(text)) fail('RUNTIME_HYGIENE', relative);
    if (relative.endsWith('/SKILL.md')) {
      const frontmatter = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n/), name = frontmatter?.[1].match(/^name:\s*(.+)$/m)?.[1].trim(), description = frontmatter?.[1].match(/^description:\s*(.+)$/m)?.[1].trim();
      if (name !== path.basename(path.dirname(relative)) || !description || description.length > 1024) fail('SKILL_METADATA', relative);
      if (description && !yamlScalarSafe(description)) fail('SKILL_YAML', relative + ': quote the description; a plain YAML value cannot contain ": " or " #" or start with an indicator');
      if (text.split('\n').length > 500) fail('SKILL_SIZE', relative);
      if (/^skills\/[^/]+\/SKILL\.md$/.test(relative) && description) descriptionTotal += description.replace(/^(['"])(.*)\1$/, '$2').length;
    }
    if (relative.includes('/references/') && text.trim().length < 500) fail('THIN_REFERENCE', relative);
  }
  // Hosts list every skill description in each conversation; Codex budgets about 8,000 characters for all of them.
  if (descriptionTotal > 7800) fail('DESCRIPTION_BUDGET', `skill descriptions total ${descriptionTotal} characters (limit 7800)`);
  else if (descriptionTotal > 7500) warnings.push(`Skill descriptions total ${descriptionTotal} characters; the limit is 7800.`);
  const linkedTargets = new Set();
  for (const [relative, text] of texts) for (const match of text.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
    const href = match[1].replace(/^<|>$/g, '');
    if (/^(https?:|mailto:)/i.test(href)) continue;
    try {
      const split = href.indexOf('#'), filePart = decodeURIComponent(split < 0 ? href : href.slice(0, split)), fragment = split < 0 ? '' : decodeURIComponent(href.slice(split + 1));
      const target = filePart ? path.resolve(base, path.dirname(relative), filePart) : path.join(base, relative);
      if (filePart && relative.startsWith('skills/')) linkedTargets.add(path.relative(base, target));
      if (!within(target)) fail('LINK_ESCAPE', relative + ' -> ' + href);
      else if (!fs.existsSync(target)) fail('BROKEN_LINK', relative + ' -> ' + href);
      else if (fragment && target.endsWith('.md') && !anchors(texts.get(path.relative(base, target)) ?? read(path.relative(base, target))).has(fragment)) fail('BROKEN_ANCHOR', relative + ' -> ' + href);
    } catch (error) { fail('LINK_ENCODING', relative + ': ' + error.message); }
  }
  // A reference or template that no skill file links is never loaded; a "(moved)" pointer kept for hosted-update parity is exempt.
  for (const relative of files.filter(file => /^skills\/[^/]+\/(references|templates)\//.test(file))) {
    if (linkedTargets.has(relative) || (relative.endsWith('.md') && /^# .*\(moved\)\s*$/.test(read(relative).split('\n')[0]))) continue;
    fail('REFERENCE_REACH', relative + ': link it from the step where it applies, or replace it with a "(moved)" pointer');
  }
  // Host discovery proved recursive in dev.30: scan every SKILL.md, including source mirrors.
  const discovered = files.filter(file => file.endsWith('/SKILL.md')).filter(file => /^---\r?\n/.test(read(file)));
  const expectedEntrypoints = files.filter(file => /^skills\/[^/]+\/SKILL\.md$/.test(file));
  if (!isDeepStrictEqual(discovered.sort(), expectedEntrypoints.sort())) fail('RECURSIVE_DISCOVERY', 'Only canonical active roots may expose skill frontmatter');
  const owners = Array.isArray(registry.owners) ? registry.owners.filter(owner => owner && typeof owner === 'object' && typeof owner.id === 'string') : [];
  const ownerIds = owners.map(owner => owner.id), actualOwners = files.filter(file => /^skills\/[^/]+\/SKILL\.md$/.test(file)).map(file => file.split('/')[1]).sort();
  errors.push(...validatePresentation(base, files, actualOwners));
  // A dated generator snapshot states its date, and the research owner cites the same date where it links it.
  for (const relative of files.filter(file => /^skills\/research-evidence\/references\/[a-z-]+-snapshot\.md$/.test(file))) {
    const date = read(relative).split('\n').slice(0, 5).join('\n').match(/^Snapshot date: (\d{4}-\d{2}-\d{2})\./m)?.[1];
    const name = path.basename(relative), entry = read('skills/research-evidence/SKILL.md');
    const at = entry.indexOf('(references/' + name + ')');
    if (!date) fail('SNAPSHOT_DATE', relative + ': state "Snapshot date: YYYY-MM-DD." in its first lines');
    else if (at < 0 || !entry.slice(at, at + 160).includes(date)) fail('SNAPSHOT_DATE', relative + ': Research must link it with its date ' + date);
  }
  // The capability card states what Studio executes; every tool it names must exist and every owner must be real.
  try {
    const card = json('skills/workflow-orchestrator/assets/capability-card.json');
    const allowed = new Set(card.requirement_values ?? []), hosts = new Set(Object.keys(card.host_profiles ?? {}));
    if (card.schema_version !== 1 || card.path_base !== 'plugin_root' || !/^\d{4}-\d{2}-\d{2}$/.test(String(card.checked)) || !Array.isArray(card.capabilities) || !card.capabilities.length) fail('CAPABILITY_CARD', 'schema, plugin_root path base, check date and capabilities');
    const ids = new Set();
    for (const item of card.capabilities ?? []) {
      const where = String(item?.id);
      if (!/^[a-z_]+$/.test(where) || ids.has(where)) fail('CAPABILITY_CARD', where + ': id must be unique snake_case');
      ids.add(where);
      if (!['studio', 'host', 'external'].includes(item.executed_by) || !actualOwners.includes(item.owner)) fail('CAPABILITY_CARD', where + ': executed_by and an installed owner');
      for (const field of ['does', 'delivers', 'when_missing', 'observed']) if (typeof item[field] !== 'string' || !item[field].trim()) fail('CAPABILITY_CARD', where + ': ' + field);
      for (const tool of item.tools ?? []) if (!files.includes(tool)) fail('CAPABILITY_CARD', where + ': missing tool ' + tool);
      if (item.executed_by === 'studio' && !(item.tools ?? []).length) fail('CAPABILITY_CARD', where + ': a Studio capability names its tool');
      for (const need of [...(item.requires ?? []), ...(item.optional ?? [])]) if (!allowed.has(need)) fail('CAPABILITY_CARD', where + ': unknown requirement ' + need);
      for (const host of item.hosts ?? []) if (!hosts.has(host)) fail('CAPABILITY_CARD', where + ': unknown host profile ' + host);
    }
    for (const relative of ['skills/workflow-orchestrator/SKILL.md', 'skills/workflow-orchestrator/references/capabilities-and-handoffs.md', 'skills/pipeline-core/references/role-skill-map.md']) {
      if (!read(relative).includes('capability-card.json)')) fail('CAPABILITY_CARD', relative + ' must link the capability card');
    }
  } catch (error) { fail('CAPABILITY_CARD', error.message); }
  // The environment check lists every tool behind the capability card's requirements; both must name the same things.
  try {
    const card = json('skills/workflow-orchestrator/assets/capability-card.json');
    const spec = json('skills/workflow-orchestrator/assets/environment-check/tools.json');
    const filled = value => typeof value === 'string' && value.trim().length > 0;
    const values = new Set(card.requirement_values ?? []), capabilities = new Set((card.capabilities ?? []).map(item => item.id));
    if (spec.schema_version !== 1 || !/^\d{4}-\d{2}-\d{2}$/.test(String(spec.checked)) || !Array.isArray(spec.tools) || !spec.tools.length) fail('ENVIRONMENT_CHECK', 'tools.json: schema, check date and tools');
    const ids = new Set();
    for (const tool of spec.tools ?? []) {
      const where = String(tool?.id);
      if (!/^[a-z_]+$/.test(where) || ids.has(where)) fail('ENVIRONMENT_CHECK', where + ': id must be unique snake_case');
      ids.add(where);
      if (tool.requirement !== undefined && !values.has(tool.requirement)) fail('ENVIRONMENT_CHECK', where + ': unknown requirement ' + tool.requirement);
      if (tool.capability !== undefined && !capabilities.has(tool.capability)) fail('ENVIRONMENT_CHECK', where + ': unknown capability ' + tool.capability);
      if (tool.pinned_by !== undefined && !files.includes(tool.pinned_by)) fail('ENVIRONMENT_CHECK', where + ': missing pinned_by ' + tool.pinned_by);
      if (tool.used_by !== undefined && !files.includes(tool.used_by)) fail('ENVIRONMENT_CHECK', where + ': missing used_by ' + tool.used_by);
      if (tool.requirement === undefined && tool.capability === undefined && tool.pinned_by === undefined && tool.used_by === undefined) fail('ENVIRONMENT_CHECK', where + ': maps to no requirement, capability, project file or user');
      // One required set: no tool is optional, and a workspace tool names the starter it installs.
      if ('optional' in tool) fail('ENVIRONMENT_CHECK', where + ': every tool is required; remove optional');
      if (tool.kind === 'workspace' && !(filled(tool.workspace_name) && files.includes(tool.pinned_by ?? '') && files.includes(String(tool.pinned_by).replace(/package\.json$/, 'package-lock.json')))) fail('ENVIRONMENT_CHECK', where + ': a workspace tool needs workspace_name and a starter with package.json and package-lock.json');
      const install = tool.install ?? {};
      if (!(install.any || ['linux', 'macos', 'windows'].every(system => install[system]))) fail('ENVIRONMENT_CHECK', where + ': install steps for every system');
    }
    // Every tool has a status for every host the plugin runs in; an observed status names its evidence.
    const hostIds = (spec.hosts ?? []).map(host => host?.id), statuses = Object.keys(spec.host_statuses ?? {});
    if (!isDeepStrictEqual([...hostIds].sort(), ['chatgpt', 'chatgpt_work', 'claude_apps', 'claude_code', 'codex'])) fail('ENVIRONMENT_CHECK', 'hosts must be chatgpt, chatgpt_work, codex, claude_code and claude_apps');
    if (!isDeepStrictEqual([...statuses].sort(), ['check', 'install', 'not_supported', 'observed', 'per_project'])) fail('ENVIRONMENT_CHECK', 'host_statuses must define observed, check, install, per_project and not_supported');
    for (const host of spec.hosts ?? []) if (!(card.host_profiles ?? {})[host?.profile] || !filled(host?.install_guide)) fail('ENVIRONMENT_CHECK', String(host?.id) + ': profile from the capability card and an install guide');
    for (const tool of spec.tools ?? []) for (const id of hostIds) {
      const entry = tool.hosts?.[id];
      if (!entry || !statuses.includes(entry.status)) fail('ENVIRONMENT_CHECK', tool.id + ': no valid status for host ' + id);
      else if (['observed', 'not_supported'].includes(entry.status) && !filled(entry.note)) fail('ENVIRONMENT_CHECK', tool.id + ' on ' + id + ': ' + entry.status + ' needs its evidence or reason in note');
    }
    if (!read('skills/workflow-orchestrator/assets/environment-check/README.md').includes('<!-- BEGIN HOST MATRIX -->')) fail('ENVIRONMENT_CHECK', 'README must carry the host matrix');
    const covered = new Set(spec.tools.map(tool => tool.requirement));
    for (const need of values) if (!['host_tool', 'user_browser', 'network', 'none'].includes(need) && !covered.has(need)) fail('ENVIRONMENT_CHECK', 'no tool checks the requirement ' + need);
    for (const relative of ['skills/workflow-orchestrator/SKILL.md', 'skills/workflow-orchestrator/references/capabilities-and-handoffs.md']) {
      if (!read(relative).includes('assets/environment-check/README.md)')) fail('ENVIRONMENT_CHECK', relative + ' must link the environment check');
    }
    if (!files.includes('skills/workflow-orchestrator/assets/environment-check/check_environment.py')) fail('ENVIRONMENT_CHECK', 'check_environment.py is missing');
  } catch (error) { fail('ENVIRONMENT_CHECK', error.message); }
  if (registry.schema_version !== 1 || owners.length !== expectedOwnerCount || new Set(ownerIds).size !== expectedOwnerCount || !isDeepStrictEqual([...ownerIds].sort(), actualOwners)) fail('OWNER_ROSTER', 'Registry must match all thirty-seven installed skill roots');
  // UI names are distinct from stable routing IDs. Check every discovered root,
  // including future additions, rather than only a fixed list of current names.
  const nameSpellings = new Map([['ai', 'AI'], ['ugc', 'UGC'], ['hyperframes', 'HyperFrames'], ['opencut', 'OpenCut']]);
  // Owner-approved display names (2026-10-24, docs/skill-naming.md); an ID not listed derives its name from its words.
  const displayOverrides = new Map([
    ['audio-production-director', 'Audio Production'],
    ['cinematography', 'Camera And Light'],
    ['commercial-video-campaign-director', 'Video Campaign'],
    ['commercial-visual-campaign-director', 'Visual Campaign'],
    ['creative-music-video-director', 'Music Video'],
    ['creative-video-producer', 'Video Producer'],
    ['delivery-documentation', 'Delivery Pack'],
    ['ecommerce-campaign-strategy-director', 'Sales Campaign Strategy'],
    ['hipson-adapter', 'Hipson Handoff'],
    ['humanizer', 'Copy Polish'],
    ['hyperframes-workflow', 'Motion Graphics'],
    ['image-prompt-architect', 'Image Prompt'],
    ['instruction-packet-factory', 'Task Handoff'],
    ['marketing', 'Brand Strategy'],
    ['opencut-video-studio', 'FrameCut'],
    ['output-critic-iteration', 'Output Review'],
    ['pipeline-core', 'Studio Core'],
    ['reference-pack-curator', 'Reference Pack'],
    ['remotion-video-production', 'Remotion Video'],
    ['research-evidence', 'Research'],
    ['screenplay-story-architect', 'Story And Screenplay'],
    ['static-graphic-design-creator', 'Graphic Design'],
    ['storyboard-board-architect', 'Storyboard Board'],
    ['storyboard-sequence-architect', 'Shot Sequence'],
    ['storytelling', 'Story Logic'],
    ['studio-workstyle-profile', 'Workstyle Profile'],
    ['tool-routing-cost', 'Tools And Costs'],
    ['ugc', 'UGC Ads'],
    ['video-prompt-architect', 'Video Prompt'],
    ['workflow-orchestrator', 'FrameCore Studio Guide'],
    ['workflow-self-improvement', 'Studio Retrospective']
  ]);
  const displayNames = new Set();
  for (const id of actualOwners) {
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)) fail('SKILL_ID_FORMAT', id);
    const relative = 'skills/' + id + '/agents/openai.yaml';
    if (!files.includes(relative)) { fail('SKILL_DISPLAY_NAME', relative + ': missing UI metadata'); continue; }
    const config = read(relative);
    // The naming standard uses a double-quoted scalar directly under interface.
    const sections = [...config.matchAll(/^interface:[ \t]*\r?\n((?:[ \t]+[^\r\n]*\r?\n|[ \t]*\r?\n)*)/gm)];
    const entries = [...(sections[0]?.[1] ?? '').matchAll(/^  display_name:[ \t]*("(?:[^"\\\r\n]|\\[^\r\n])*")[ \t]*$/gm)];
    let title;
    try { if (sections.length === 1 && entries.length === 1) title = JSON.parse(entries[0][1]); } catch { /* invalid scalar fails below */ }
    const expected = displayOverrides.get(id) ?? id.split('-').map(word => nameSpellings.get(word) ?? word[0].toUpperCase() + word.slice(1)).join(' ');
    if (title !== expected) fail('SKILL_DISPLAY_NAME', relative + ': expected interface.display_name ' + JSON.stringify(expected));
    // Included agent metadata also requires a short UI description. Enforce the
    // repository's quoted-scalar format and the 25–64 character authoring range.
    // This checks source compatibility, not registration in an active client.
    const blurbs = [...(sections[0]?.[1] ?? '').matchAll(/^  short_description:[ \t]*("(?:[^"\\\r\n]|\\[^\r\n])*")[ \t]*$/gm)];
    let blurb;
    try { if (sections.length === 1 && blurbs.length === 1) blurb = JSON.parse(blurbs[0][1]); } catch { /* invalid scalar fails below */ }
    if (typeof blurb !== 'string' || !blurb.trim() || [...blurb].length < 25 || [...blurb].length > 64) fail('SKILL_SHORT_DESCRIPTION', relative + ': expected one interface.short_description string of 25–64 characters');
    if (typeof title === 'string') {
      if (displayNames.has(title)) fail('SKILL_DISPLAY_NAME_DUPLICATE', title);
      displayNames.add(title);
    }
  }
  // Overlapping owners must name their neighbor in the catalog description, and the
  // legacy audio alias stays explicit-only so it never competes with its replacement.
  const descriptionOf = id => (texts.get('skills/' + id + '/SKILL.md') ?? '').match(/^description:\s*(.+)$/m)?.[1] ?? '';
  for (const [id, neighbors] of [['storytelling', ['Story And Screenplay', 'Shot Sequence']], ['marketing', ['Sales Campaign Strategy']], ['ecommerce-campaign-strategy-director', ['Brand Strategy']], ['instruction-packet-factory', ['Brief Architect', 'Hipson Handoff']], ['hipson-adapter', ['Task Handoff']], ['brief-architect', ['Task Handoff']], ['pipeline-core', ['FrameCore Studio Guide']]]) {
    for (const neighbor of neighbors) if (!descriptionOf(id).includes(neighbor)) fail('ROUTING_BOUNDARY', id + ' -> ' + neighbor);
  }
  for (const id of ['producer-ai-task-builder', 'hipson-adapter', 'workflow-self-improvement']) {
    const metadata = files.includes('skills/' + id + '/agents/openai.yaml') ? read('skills/' + id + '/agents/openai.yaml') : '';
    if (!/^policy:\r?\n  allow_implicit_invocation: false[ \t]*$/m.test(metadata)) fail('EXPLICIT_ONLY_POLICY', id);
  }
  const routing = texts.get('skills/workflow-orchestrator/SKILL.md') ?? '';
  const identityBegin = '<!-- BEGIN PACKAGE IDENTITY -->', identityEnd = '<!-- END PACKAGE IDENTITY -->';
  const start = routing.indexOf(identityBegin), end = routing.indexOf(identityEnd);
  let entryIdentity;
  try {
    if (routing.split(identityBegin).length === 2 && routing.split(identityEnd).length === 2 && start >= 0 && end > start) {
      entryIdentity = JSON.parse(routing.slice(start + identityBegin.length, end));
    }
  } catch { /* malformed projection fails below */ }
  if (!isDeepStrictEqual(entryIdentity, {name: portable.name, version: portable.version})) fail('PACKAGE_IDENTITY', 'Entry identity must match the current manifests exactly');
  if (start < 0 || end < 0 || end >= routing.indexOf('## Immediate complete startup response')) fail('PACKAGE_IDENTITY_PLACEMENT', 'Read package identity before resolving version or startup requests');
  for (const phrase of ['plugin-version/installation-status request', 'Reread this entry through the active host', 'read package version', 'host-supplied skill revision', 'current sources for the same bundle conflict', 'saved hosted release', 'latest GitHub release', 'Never report a version from memory', 'current version cannot be confirmed']) {
    if (!routing.includes(phrase)) fail('VERSION_REPORTING_POLICY', phrase);
  }
  // Keep the entry compact: rare paths live in linked references that must keep their rules.
  const entryDescription = routing.match(/^---\r?\n[\s\S]*?^description:\s*(.+)$/m)?.[1] ?? '';
  if (Buffer.byteLength(routing) > 32000 || entryDescription.length > 450) fail('ORCHESTRATOR_BUDGET', 'Entry SKILL.md must stay within 32000 bytes and a 450-character description');
  for (const [reference, phrases] of [['references/version-reporting.md', ['Never choose the larger number', 'A version question authorizes no installation']], ['references/routing-boundaries.md', ['The sequence and board owners are distinct', 'Music-video direction is a separate route', 'For an unsupported module']]]) {
    const body = texts.get('skills/workflow-orchestrator/' + reference) ?? '';
    if (!routing.includes('](' + reference + ')') || phrases.some(phrase => !body.includes(phrase))) fail('ORCHESTRATOR_REFERENCE', reference);
  }
  const routeRows = routing.split(/\r?\n/).filter(line => line.startsWith('|') && line.includes('/SKILL.md)'));
  const linkedOwnersByRow = new Map();
  const seenRouteRows = new Set();
  for (const row of routeRows) {
    if (seenRouteRows.has(row)) fail('OWNER_ROUTE', 'Duplicate route row: ' + row.split('|')[1]?.trim());
    seenRouteRows.add(row);
    const linkedOwners = [...row.matchAll(/\(\.\.\/([a-z0-9-]+)\/SKILL\.md\)/g)].map(match => match[1]);
    if (new Set(linkedOwners).size !== linkedOwners.length) fail('OWNER_ROUTE', 'Duplicate owner link in route row: ' + row.split('|')[1]?.trim());
    for (const id of linkedOwners) {
      if (!linkedOwnersByRow.has(id)) linkedOwnersByRow.set(id, []);
      linkedOwnersByRow.get(id).push(row);
    }
  }
  for (const owner of owners) {
    if (owner.entrypoint !== 'skills/' + owner.id + '/SKILL.md' || !texts.has(owner.entrypoint)) { fail('OWNER_ENTRYPOINT', owner.id); continue; }
    const expectedRoute = !['workflow-orchestrator', 'producer-ai-task-builder'].includes(owner.id);
    if (owner.route_required !== expectedRoute) fail('OWNER_ROUTE_CONTRACT', owner.id);
    if (owner.route_required && !linkedOwnersByRow.has(owner.id)) fail('OWNER_ROUTE', owner.id + ': no table route');
    if (owner.id !== 'research-evidence') {
      const instructions = texts.get(owner.entrypoint), index = instructions.indexOf('../research-evidence/SKILL.md');
      if (index < 0) fail('RESEARCH_HANDOFF', owner.id);
      else {
        // Specialists keep the shared gate and describe it as trigger-based, not as an unconditional search.
        const lead = instructions.slice(Math.max(0, index - 220), index);
        if (!/\bconditional\b/i.test(lead) || /\bmandatory\b/i.test(lead)) fail('RESEARCH_CONDITIONAL', owner.id);
      }
    }
  }
  const operationRoutes = Array.isArray(registry.operation_routes) ? registry.operation_routes : [];
  const requiredOperations = ['Image supplied as a reference for a new asset', 'Approved base image supplied for an edit', 'Existing image explicitly supplied for review'];
  for (const need of requiredOperations) if (operationRoutes.filter(route => route?.need === need).length !== 1) fail('OPERATION_ROUTE_CONTRACT', 'Expected exactly one operation contract: ' + need);
  for (const contract of operationRoutes) {
    if (!contract || typeof contract.need !== 'string' || !Array.isArray(contract.owners) || !contract.owners.length || contract.owners.some(id => !ownerIds.includes(id))) {
      fail('OPERATION_ROUTE_CONTRACT', String(contract?.need ?? 'invalid route'));
      continue;
    }
    const matchingRows = routeRows.filter(row => row.split('|')[1]?.trim() === contract.need);
    if (matchingRows.length !== 1) {
      fail('OPERATION_ROUTE', contract.need + ': expected one row; found ' + matchingRows.length);
      continue;
    }
    const actualOwners = [...matchingRows[0].matchAll(/\(\.\.\/([a-z0-9-]+)\/SKILL\.md\)/g)].map(match => match[1]).sort();
    if (!isDeepStrictEqual(actualOwners, [...contract.owners].sort())) fail('OPERATION_ROUTE', contract.need + ': expected ' + contract.owners.join(', ') + '; found ' + actualOwners.join(', '));
  }
  const upgrade = json('scripts/creative-upgrade-contracts.json');
  if (upgrade.schema_version !== 1 || !Array.isArray(upgrade.owners) || !Array.isArray(upgrade.references) || !Array.isArray(upgrade.source_ids)) fail('CREATIVE_REGISTRY', 'Invalid creative resource registry');
  else {
    const linkedBy = new Map(upgrade.references.map(relative => [relative, []]));
    for (const owner of upgrade.owners) {
      if (!ownerIds.includes(owner)) { fail('CREATIVE_OWNER', String(owner)); continue; }
      const relative = 'skills/' + owner + '/SKILL.md';
      const destinations = [...(texts.get(relative) ?? '').matchAll(/\[[^\]]+\]\(([^)]+)\)/g)].map(match => path.relative(base, path.resolve(base, path.dirname(relative), match[1].split('#')[0])));
      const linked = upgrade.references.filter(reference => destinations.includes(reference));
      if (!linked.length) fail('CREATIVE_OWNER_ROUTE', owner);
      for (const reference of linked) linkedBy.get(reference).push(owner);
    }
    for (const [reference, linked] of linkedBy) if (!texts.has(reference) || !linked.length) fail('CREATIVE_REFERENCE_ROUTE', reference);
    const sources = texts.get('skills/research-evidence/references/creative-upgrade-sources.md') ?? '';
    const sourceIds = [...sources.matchAll(/^### (C\d+):/gm)].map(match => match[1]);
    if (!isDeepStrictEqual([...sourceIds].sort(), [...upgrade.source_ids].sort()) || new Set(sourceIds).size !== sourceIds.length) fail('CREATIVE_SOURCES', 'Source cards must match their registry');
  }
  const contracts = Array.isArray(registry.critical_contracts) ? registry.critical_contracts.filter(item => item && typeof item === 'object' && typeof item.id === 'string') : [];
  if (!isDeepStrictEqual(contracts.map(item => item.id).sort(), [...criticalIds].sort())) fail('CRITICAL_ROSTER', 'Critical contract IDs changed or missing');
  for (const contract of contracts) {
    const text = texts.get(contract.path);
    if (!text || !Array.isArray(contract.required_patterns) || !contract.required_patterns.length) { fail('CRITICAL_CONTRACT', contract.id); continue; }
    for (const pattern of contract.required_patterns) {
      try { if (!new RegExp(pattern, 'i').test(text)) fail('CRITICAL_CONTRACT', contract.id + ': missing ' + pattern); }
      catch { fail('CONTRACT_PATTERN', contract.id); }
    }
  }
  for (const [relative, prefix] of Object.entries(registry.release_documents ?? {})) {
    if (!(texts.get(relative) ?? '').includes(prefix + ' ' + portable.version + '.')) fail('DOC_VERSION', relative);
  }
  if (!isDeepStrictEqual(Object.keys(registry.release_documents ?? {}).sort(), ['README.md', 'docs/migration-status.md'])) fail('RELEASE_DOCS', 'Expected README and migration status markers');
  const migration = texts.get('docs/migration-status.md') ?? '';
  for (const owner of owners) if (!migration.includes(owner.id)) fail('MIGRATION_OWNER', owner.id);
  let evaluations;
  try {
    const effective = loadEffectiveEvals(base);
    for (const item of effective.cases) {
      if (item.status !== 'planned') fail('EVAL_EXECUTION_CLAIM', item.id);
      if (typeof item.user_request !== 'string' || !item.user_request.trim() || !Array.isArray(item.checks) || !item.checks.length || item.checks.some(check => typeof check !== 'string' || !check.trim()) || typeof item.expected_branch !== 'string' || !item.expected_branch.trim() || !item.context || typeof item.context !== 'object' || Array.isArray(item.context) || !Array.isArray(item.available_assets)) fail('EVAL_SCHEMA', item.id);
      if (!['textual_fixture_no_execution', 'planned_fixture_only'].includes(item.tool_state?.mode)) fail('EVAL_TOOL_EXECUTION', item.id);
      if (!webStates.has(item.tool_state?.web_search)) fail('EVAL_WEB_STATE', item.id);
      if (!['required', 'not_triggered', 'not_applicable', 'prohibited_by_user'].includes(item.research_expectation)) fail('EVAL_RESEARCH', item.id);
      if (['not_applicable', 'not_triggered'].includes(item.research_expectation) && !item.research_exemption_reason) fail('EVAL_EXEMPTION', item.id);
      if ((item.research_expectation === 'required') !== researchTriggers.has(item.research_trigger)) fail('EVAL_RESEARCH_TRIGGER', item.id);
      if (item.research_expectation === 'not_triggered' && item.expected_owners?.includes('research-evidence')) fail('EVAL_UNTRIGGERED_OWNER', item.id);
      if ((item.research_expectation === 'prohibited_by_user') !== (item.tool_state?.web_search === 'prohibited_by_user')) fail('EVAL_BROWSE_BOUNDARY', item.id);
    }
    if (!isDeepStrictEqual([...effective.overrides_applied].sort(), ['S01', 'S18', 'S32', 'S35', 'S45', 'S50', 'S51'])) fail('OVERRIDE_COVERAGE', 'The seven reviewed inherited cases require their effective overrides');
    for (const id of ['S35-CROP', 'S35-PAD', 'S35-CONFLICT', 'S45-FINAL']) if (!effective.cases.some(item => item.id === id)) fail('OVERRIDE_VARIANT', id);
    const hostCases = effective.cases.filter(item => item.provenance.source_file === 'studio-behavior-cases.json');
    if (hostCases.length !== 25 || new Set(hostCases.map(item => item.family)).size !== 25) fail('HOST_SCENARIO_COVERAGE', 'Expected twenty-five distinct planned families');
    for (const state of ['unavailable', 'timeout', 'error']) if (!hostCases.some(item => item.tool_state.web_search === state)) fail('RESEARCH_FAILURE_COVERAGE', state);
    if (!hostCases.some(item => item.research_expectation === 'not_triggered' && item.tool_state.web_search === 'unavailable') || !effective.cases.some(item => item.research_expectation === 'required' && item.tool_state?.web_search === 'unavailable')) fail('RESEARCH_CONDITIONAL_COVERAGE', 'Unavailable research needs untriggered and triggered planned cases');
    for (const item of hostCases) {
      if (item.execution_status !== 'not_run' || !Array.isArray(item.required_evidence) || !item.required_evidence.length || !Array.isArray(item.expected_owners) || item.expected_owners.some(id => !ownerIds.includes(id))) fail('HOST_EVIDENCE_CONTRACT', item.id);
    }
    const practiceCases = effective.cases.filter(item => item.provenance.source_file === 'knowledge-practice-cases.json');
    if (practiceCases.length !== 12 || new Set(practiceCases.map(item => item.family)).size !== 12) fail('KNOWLEDGE_COVERAGE', 'Expected twelve distinct knowledge-practice families');
    for (const item of practiceCases) if (item.execution_status !== 'not_run' || !Array.isArray(item.required_evidence) || !item.required_evidence.length || !Array.isArray(item.expected_owners) || !item.expected_owners.length || item.expected_owners.some(id => !ownerIds.includes(id))) fail('KNOWLEDGE_EVIDENCE', item.id);
    const integrationCases = effective.cases.filter(item => item.provenance.source_file === 'workflow-kit-cases.json');
    if (integrationCases.length !== 14 || new Set(integrationCases.map(item => item.family)).size !== 14) fail('INTEGRATION_COVERAGE', 'Expected fourteen planned integration families');
    for (const item of integrationCases) if (item.execution_status !== 'not_run' || !Array.isArray(item.required_evidence) || !item.required_evidence.length || !Array.isArray(item.expected_owners) || !item.expected_owners.length || item.expected_owners.some(id => !ownerIds.includes(id))) fail('INTEGRATION_EVIDENCE', item.id);
    const activeOwnerIds = owners.filter(owner => owner.route_required || owner.id === 'workflow-orchestrator').map(owner => owner.id);
    if (!isDeepStrictEqual([...new Set([...practiceCases, ...integrationCases].flatMap(item => item.expected_owners ?? []))].sort(), [...activeOwnerIds].sort())) fail('KNOWLEDGE_OWNERS', 'Planned knowledge and integration cases must cover every active owner');
    evaluations = {legacy: effective.legacy_cases, overrides: effective.overrides_applied, added_variants: effective.additional_cases, host_scenarios: effective.host_scenarios, knowledge_scenarios: effective.knowledge_scenarios, integration_scenarios: effective.integration_scenarios, learning_scenarios: effective.learning_scenarios, campaign_scenarios: effective.campaign_scenarios, total_planned: effective.cases.length, executed: 0};
  } catch (error) { fail('EFFECTIVE_EVALS', error.message); }
  // The historical validate-package.mjs / package.test.mjs suite was retired on 2026-10-10 (owner decision).
  const canonical = {...result(), files: files.length, owners: owners.length, evaluations};
  let legacyReport = {status: 'RETIRED', scope: 'Historical validator retired on 2026-10-10 (owner decision); canonical checks only'};
  return {status: canonical.status === 'PASS' && ['NOT_RUN', 'PASS', 'RETIRED'].includes(legacyReport.status) ? 'PASS' : 'FAIL', canonical, legacy: legacyReport};
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), root = args.find(arg => !arg.startsWith('--')) ?? path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  const result = validateStudio(root, {legacy: args.includes('--legacy')});
  console.log(JSON.stringify(result, null, 2));
  if (result.status !== 'PASS') process.exitCode = 1;
}
