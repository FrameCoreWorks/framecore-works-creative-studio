import fs from 'node:fs';
import path from 'node:path';
import {isDeepStrictEqual} from 'node:util';

const canvas = 'skills/hyperframes-workflow/assets/motion-toolkit';
const three = 'skills/remotion-video-production/assets/three-motion-example';
const turntable = 'skills/remotion-video-production/assets/gltf-turntable';
const kinetic = 'skills/remotion-video-production/assets/kinetic-type-starter';
const gsapStarter = 'skills/hyperframes-workflow/assets/gsap-motion-starter';
const singleFile = 'skills/hyperframes-workflow/assets/single-file-preview';
const scenesDir = 'skills/hyperframes-workflow/assets/motion-scenes';
export function validateMotionToolkit(root) {
  const errors = [];
  const fail = detail => errors.push({code: 'MOTION_TOOLKIT', detail});
  const read = relative => fs.readFileSync(path.join(root, relative), 'utf8');
  const required = [
    ...['README.md','package.json','package-lock.json','index.html','app.mjs','build.mjs','server.mjs','timeline.mjs','timeline.test.mjs','renderers.mjs','lottie-fixture.mjs','export.mjs'].map(name => `${canvas}/${name}`),
    ...['README.md','package.json','package-lock.json','tsconfig.json','remotion.config.ts','src/index.tsx'].map(name => `${three}/${name}`),
    ...['README.md','package.json','package-lock.json','tsconfig.json','remotion.config.ts','src/index.tsx','public/sample-product.glb','tools/make_sample_glb.py'].map(name => `${turntable}/${name}`),
    ...['README.md','retime.py'].map(name => `skills/hyperframes-workflow/assets/animate-voice/${name}`),
    ...['README.md','package.json','package-lock.json','tsconfig.json','remotion.config.ts','check-score.mjs','motion-score.json','src/index.ts','src/Root.tsx','src/motion.ts','src/KineticType.tsx'].map(name => `${kinetic}/${name}`),
    ...['README.md','package.json','package-lock.json','index.html','main.mjs','check-score.mjs','motion-score.json'].map(name => `${gsapStarter}/${name}`),
    'skills/hyperframes-workflow/references/motion-craft.md',
    'skills/hyperframes-workflow/references/motion-contract-json.md',
    `${singleFile}/README.md`,
    `${scenesDir}/README.md`,
    'skills/hyperframes-workflow/assets/motion-review/README.md',
    'skills/hyperframes-workflow/assets/motion-review/review-frames.mjs',
    ...['README.md','sync.mjs','examples/voice-over.srt'].map(name => `skills/hyperframes-workflow/assets/motion-sync/${name}`),
    ...['README.md','video-export.mjs','export-video.mjs'].map(name => `skills/hyperframes-workflow/assets/motion-export/${name}`),
    ...['README.md','revise.mjs'].map(name => `skills/hyperframes-workflow/assets/motion-revise/${name}`),
    ...['README.md','render.py'].map(name => `skills/hyperframes-workflow/assets/motion-render/${name}`),
    ...['README.md','styles.json'].map(name => `skills/hyperframes-workflow/assets/motion-styles/${name}`),
    ...['beats.py','music_edit.py'].map(name => `skills/hyperframes-workflow/assets/motion-sync/${name}`),
    'skills/hyperframes-workflow/references/kaventro-motion-designer-adaptation.md',
    'skills/hyperframes-workflow/references/product-films.md',
    'skills/hyperframes-workflow/assets/motion-scenes/examples/app-film.motion-score.json',
    'skills/hyperframes-workflow/assets/motion-scenes/examples/color-block.motion-score.json',
    ...['README.md','sound.py','synth.py','music.py','direction.py','sound-base.json','recipe.py','generate.py','compose.py'].map(name => `skills/hyperframes-workflow/assets/motion-sound/${name}`),
    'skills/hyperframes-workflow/assets/motion-review/critique.py',
    'skills/hyperframes-workflow/references/motion-sound-design.md',
    ...['LICENSE','README.md','source-manifest.json'].map(name => `integrations/kaventro-motion-designer/${name}`),
    `${scenesDir}/motion-scenes.mjs`,
    `${scenesDir}/examples/all-kinds.motion-score.json`,
    `${scenesDir}/examples/two-statements.motion-score.json`,
    ...['ad-offer','ad-product','ad-testimonial'].map(name => `${scenesDir}/templates/${name}.motion-score.json`),
    ...['README.md','variants.py'].map(name => `skills/hyperframes-workflow/assets/motion-variants/${name}`),
    `${scenesDir}/examples/social-captions.motion-score.json`,
    `${singleFile}/check-preview.mjs`,
    `${singleFile}/player-link.mjs`,
    `${kinetic}/src/motion-scenes.mjs`,
    `${singleFile}/motion-preview.html`,
    ...['motion-toolkit-routing.md','motion-toolkit-runtime-cards.md','motion-toolkit-sources.md'].map(name => `skills/hyperframes-workflow/references/${name}`),
    'skills/hyperframes-workflow/templates/motion-toolkit-acceptance.md',
    'skills/hyperframes-workflow/assets/manim-motion-example.py'
  ];
  for (const relative of required) {
    try {if (!read(relative).trim()) fail(`Empty: ${relative}`);} catch {fail(`Missing: ${relative}`);}
  }
  for (const directory of [canvas, three, turntable, kinetic, gsapStarter]) {
    try {
      const pkg = JSON.parse(read(`${directory}/package.json`));
      const lock = JSON.parse(read(`${directory}/package-lock.json`));
      if (pkg.private !== true || lock.lockfileVersion !== 3) fail(`${directory}: private example and lockfile v3 required`);
      for (const group of ['dependencies', 'devDependencies']) {
        if (!isDeepStrictEqual(pkg[group], lock.packages[''][group])) fail(`${directory}: ${group} lock mismatch`);
        for (const [name, version] of Object.entries(pkg[group] ?? {})) {
          if (!/^\d+\.\d+\.\d+$/.test(version)) fail(`${directory}: ${name} needs an exact version`);
          if (lock.packages[`node_modules/${name}`]?.version !== version) fail(`${directory}: ${name} resolved version mismatch`);
        }
      }
      const remotion = Object.entries(pkg.dependencies ?? {}).filter(([name]) => name === 'remotion' || name.startsWith('@remotion/'));
      if (new Set(remotion.map(([, version]) => version)).size > 1) fail(`${directory}: Remotion versions differ`);
      for (const unwanted of ['node_modules','dist','out']) if (fs.existsSync(path.join(root,directory,unwanted))) fail(`${directory}: ${unwanted} must stay outside the installed package`);
    } catch (error) {fail(`${directory}: ${error.message}`);}
  }
  // Both starters must share one contract and one checker so runtimes stay comparable.
  for (const file of ['motion-score.json', 'check-score.mjs']) {
    try { if (read(`${kinetic}/${file}`) !== read(`${gsapStarter}/${file}`)) fail(`Starter ${file} differs between runtimes`); } catch {}
  }
  // One scene engine: the Remotion copy is byte-identical and the preview embeds it without export keywords.
  try {
    const engine = read(`${scenesDir}/motion-scenes.mjs`);
    if (read(`${kinetic}/src/motion-scenes.mjs`) !== engine) fail('Remotion starter scene engine differs from motion-scenes.mjs');
    const html = read(`${singleFile}/motion-preview.html`);
    const embedded = html.split(/\/\/ BEGIN motion-scenes engine[^\n]*\n/)[1]?.split('// END motion-scenes engine')[0];
    if (embedded !== engine.replaceAll('export const ', 'const ').replaceAll('export function ', 'function ')) fail('Single-file preview scene engine differs from motion-scenes.mjs');
  } catch (error) { fail(`Scene engine: ${error.message}`); }
  // One video export: the preview embeds video-export.mjs without export keywords.
  try {
    const source = read('skills/hyperframes-workflow/assets/motion-export/video-export.mjs');
    const embedded = read(`${singleFile}/motion-preview.html`).split(/\/\/ BEGIN video export[^\n]*\n/)[1]?.split('// END video export')[0];
    if (embedded !== source.replaceAll('export const ', 'const ').replaceAll('export async function ', 'async function ').replaceAll('export function ', 'function ')) fail('Single-file preview video export differs from video-export.mjs');
  } catch (error) { fail(`Video export: ${error.message}`); }
  // The single-file preview must stay offline and embed the same contract as the starters.
  try {
    const html = read(`${singleFile}/motion-preview.html`);
    if (/(?:src|href)\s*=\s*["']?(?:https?:)?\/\/|@import|url\(\s*["']?https?:/i.test(html)) fail('Single-file preview must not load external resources');
    const embedded = html.match(/<script type="application\/json" id="motion-score">([\s\S]*?)<\/script>/)?.[1];
    if (!embedded || !isDeepStrictEqual(JSON.parse(embedded), JSON.parse(read(`${kinetic}/motion-score.json`)))) fail('Single-file preview score differs from the starter contract');
  } catch (error) { fail(`Single-file preview: ${error.message}`); }
  // Planned behavior cases for the motion and sound route: structure only, never a host result.
  try {
    const suite = JSON.parse(read('evals/motion-sound-cases.json'));
    const families = ['video_route_choice', 'render_with_code_execution', 'improvement_round_budget', 'sound_for_motion_video', 'contract_revision_timing', 'sound_for_external_reel'];
    const cases = suite.cases ?? [];
    if (!/No host run/.test(suite.scope ?? '') || !suite.execution_rule) fail('Motion and sound cases need a scope without host claims and an execution rule');
    if (!isDeepStrictEqual(cases.map(item => item.family), families)) fail('Motion and sound cases must cover the six planned families in order');
    cases.forEach((item, index) => {
      if (item.id !== `MS${String(index + 1).padStart(2, '0')}`) fail(`Motion case ${index + 1}: id must be MS${String(index + 1).padStart(2, '0')}`);
      if (item.status !== 'planned' || item.execution_status !== 'not_run') fail(`${item.id}: planned cases stay not_run until an attributed host run is recorded`);
      if (!item.user_request?.trim() || !item.expected_branch?.trim()) fail(`${item.id}: request and expected branch are required`);
      for (const owner of item.expected_owners ?? []) if (!fs.existsSync(path.join(root, 'skills', owner, 'SKILL.md'))) fail(`${item.id}: unknown owner ${owner}`);
      if (!(item.expected_owners?.length && item.checks?.length && item.forbidden?.length && item.required_evidence?.length)) fail(`${item.id}: owners, checks, forbidden outcomes and required evidence are required`);
    });
  } catch (error) { fail(`Motion and sound cases: ${error.message}`); }
  return errors;
}
