---
name: cinematography
description: Use this skill for provider-neutral shot language, lens choices, camera movement, lighting, blocking, color, texture, and cinematic direction.
---

# Cinematography

Use this skill to translate direction into shot language, lighting, blocking, camera behavior, and visual texture for image, video, storyboard, or coded-video workflows.

## Language Policy

Public instructions and installation guidance stay in English. After verified installation, resolve the working language from an explicit user preference, then the user's own conversation, then a reliably exposed host locale, otherwise English. Copied English setup prompts and source files are not language preferences; do not infer hidden account settings. Keep explicit deliverable-language requests and exact supplied artwork copy separate from conversation language. Do not translate or rewrite public source files to localize a session.

## When To Use

Use this skill when:

- A visual or motion workflow needs concrete shot language rather than generic style.
- Storyboards, video prompts, image prompts, or HyperFrames scenes need camera and lighting guidance.
- The brief calls for cinematic consistency across multiple assets or scenes.

Do not use this skill to replace creative direction, write final prompts, or execute production tools.

## Inputs

Required:

- `brief_contract`: goal, audience, and format.
- `direction_contract`: visual or motion thesis and constraints.
- `reference_pack`: source authority, style cues, and suppression rules when available.

Optional:

- `storyboard_contract`: beats, shot cards, timing, or continuity.
- `copy_or_text_locks`: visible copy, supers, captions, or VO constraints.
- `platform_constraints`: aspect ratio, duration, or channel behavior.

## Outputs

Produce Cinematography Notes with:

- shot size, camera placement, and lens feel
- movement, blocking, and timing notes
- lighting, color, texture, and depth cues
- continuity constraints across shots
- shot-contract notes for frame, action, camera behavior, setting, light, and end state when it affects the next shot
- handoff notes for prompt, storyboard, or coded-video roles

## Process

1. Start from objective and viewer attention, not from decorative style.
2. Assign one primary camera behavior and one readable action to each short required beat or asset type.
3. Tie lighting and texture to mood, product readability, or narrative clarity.
4. Keep shot language concise enough to survive prompt handoff.
5. Flag any shot choice that conflicts with format, safety, or copy readability.

## Decision Rules

- Use specific visual terms only when they serve the brief.
- Prefer readable product or subject framing over dramatic but unclear shots.
- Keep motion instructions feasible for the target medium.
- Use a hard cut by default when no verified bridge carries the required state into the next shot. Document another seam only when its carrier is known.
- If a short shot needs multiple actions or camera moves, provide the reason and the observable evidence QA should use.
- If visual references conflict with the brief, preserve the brief and note the conflict.

## Guardrails

- Do not claim camera hardware, lens metadata, or production facts that are not provided.
- Do not create final generation prompts or run tools.
- Do not bury text readability constraints under cinematic language.
- Do not invent private references or brand rules.

## Handoff

Review gate: `direction_fit` for campaign direction and `structure_fit` when applied to storyboard structure.

Hand off with:

- `cinematography_notes`
- `shot_language`
- `lighting_and_texture`
- `continuity_rules`
- `shot_contract_notes`
- `prompt_constraints`

## QA Checklist

- Shot choices serve objective, audience, and format.
- Camera, lighting, and blocking are concrete.
- Text, product, or subject readability is protected.
- Continuity notes are usable by the next role.
- Camera and action complexity remains bounded or has an explicit exception.
- No final prompt or execution step is included.
