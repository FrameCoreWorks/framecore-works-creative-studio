---
name: reference-pack-curator
description: Use this skill to structure references into canonical sources, aliases, role tags, suppression rules, conflicts, and continuity anchors.
---

# Reference Pack Curator

Use this skill to structure references into source authority, aliases, role tags, suppression rules, conflicts, and continuity anchors before direction, character, storyboard, or prompt work.

## Language Policy

Public instructions and installation guidance stay in English. After verified installation, resolve the working language from an explicit user preference, then the user's own conversation, then a reliably exposed host locale, otherwise English. Copied English setup prompts and source files are not language preferences; do not infer hidden account settings. Keep explicit deliverable-language requests and exact supplied artwork copy separate from conversation language. Do not translate or rewrite public source files to localize a session.

## When To Use

Use this skill when:

- The user provides images, links, notes, examples, mood references, or source material.
- Downstream roles need to know what is canonical, inspirational, conflicting, or forbidden.
- Continuity anchors must be protected across image, video, storyboard, or coded-video work.

Do not use this skill to write final prompts, change the brief, or invent reference authority.

For poster rebuilds, packaging, logos, identity or narrow graphic edits, read
[static graphic source authority](references/static-graphic-source-authority.md).
Assign protection per property and preserve the actual current edit source.

## Inputs

Required:

- `brief_contract`: objective, constraints, audience, and acceptance criteria.
- `raw_references`: files, links, descriptions, screenshots, or source notes.
- `reference_needs`: what downstream roles need from references.

Optional:

- `aliases`: user shorthand for images, people, products, places, or motifs.
- `suppression_rules`: elements to avoid.
- `conflict_notes`: known contradictions between references.

## Outputs

Produce a Reference Pack with:

- canonical references and their roles
- control ownership and attachment requirements for references that must carry strict continuity
- mood, style, example, and exclusion references separated
- aliases and continuity anchors
- suppression rules
- conflicts and resolution notes
- handoff requirements for direction or prompting

## Process

1. Classify each reference by authority, purpose, and permitted control: identity, source, style, motion, performance, audio, or coverage.
2. Separate canonical source from mood or style inspiration.
3. Capture aliases and continuity anchors.
4. Record suppression rules and conflicts clearly.
5. Hand off only the reference meaning, not raw clutter.

## Decision Rules

- Canonical beats inspirational when they conflict.
- If reference authority is unclear, ask or label it as uncertain.
- Keep style inspiration from overriding product, character, or copy requirements.
- For a strict lock, record the alias that must be attached to each affected generation unit. A role tag alone is not a continuity carrier.
- Do not use private references not provided or approved for the task.

## Guardrails

- Do not invent source authority or claim verification that was not performed.
- Do not include private links, credentials, local-only paths, or unapproved personal data.
- Do not write final prompts or direction contracts.
- Do not erase conflicts; document how they should be handled.

## Handoff

Review gate: `reference_authority_fit`.

Hand off to `static-direction`, `motion-direction`, `music-video-direction`, `storyboard-architect`, or prompt roles with:

- `reference_pack`
- `continuity_anchors`
- `reference_roles` and `control_ownership`
- `attachment_requirements`
- `suppression_rules`
- `conflict_notes`
- `reference_gaps`

## QA Checklist

- Canonical, mood, style, and exclusion references are separated.
- Aliases are clear and reusable.
- Conflicts are visible.
- Suppression rules are actionable.
- Reference ownership is explicit enough to prevent style inspiration from overwriting locked source facts.
- Downstream roles can use the pack without reinterpreting raw references.
