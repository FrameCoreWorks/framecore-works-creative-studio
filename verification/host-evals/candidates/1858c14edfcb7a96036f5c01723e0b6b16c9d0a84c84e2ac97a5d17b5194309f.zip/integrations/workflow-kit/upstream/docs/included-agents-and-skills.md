# Included Agents And Skills

## Purpose

This inventory is the canonical public list of what this Codex workflow skill kit includes before installation. Keep counts, installed/listed items, and public install-surface names here; use [Workflow Map](workflow-map.md) for relationships and [Agent Roster](agent-roster.md) for role responsibilities.

The kit installs a project-local workflow layer for Codex and exposes the same 35 public workflow skills as repository-source native ChatGPT Skills. It includes onboarding, docs, examples, artifact contracts, gates, handoffs, validation scripts, and provider-neutral safety rules. It does not install paid external media providers, API keys, endpoint catalogs, provider CLIs, or background transfer tooling.

## Summary

| Category | Count | Installed path or source path |
| --- | ---: | --- |
| Codex role-agent templates | 20 | `.codex/agents/*.toml.template` rendered into `.codex/agents/*.toml` |
| Workflow skills | 35 | `.agents/skills/*/SKILL.md` |
| Native ChatGPT source mappings | 35 skills | `config/chatgpt-skill-sources.json` |
| Core workflow references | 12 | `.agents/skills/pipeline-core/references/` |
| Artifact schemas | 1 registry | `config/artifact-schemas.json` |
| Example workflows | 12 | `examples/*/workflow.json` |
| Installer and validation scripts | multiple | `scripts/*.mjs` and `tools/*.mjs` |

## Installed Agent Templates

These are Codex role-agent templates. During install, they are rendered into the target workspace as `.codex/agents/<role-id>.toml` with local onboarding preferences.

| Role ID | Main job |
| --- | --- |
| `intent-confirmation` | Lock the request, scope, exclusions, expected output, and immediate next step. |
| `workflow-orchestrator` | Choose the workflow route, active roles, gates, handoffs, loopbacks, and Project State. |
| `brief-architect` | Turn rough goals, notes, and constraints into a structured Brief Contract. |
| `reference-curator` | Organize visual, brand, product, continuity, and source references into a Reference Pack. |
| `research-evidence` | Verify claims, tool limits, public facts, and source-backed decisions. |
| `instruction-packet-factory` | Build bounded instruction packets, research maps, review packets, and execution packets. |
| `static-direction` | Create visual direction for static graphics, campaign assets, posters, banners, and ecommerce visuals. |
| `motion-direction` | Create direction for video, motion concepts, ad sequences, and storyboard routes. |
| `music-video-direction` | Convert song, artist, rhythm, motif, and emotional arc into a music-video direction contract. |
| `storyboard-architect` | Build beats, scenes, shot cards, transitions, timing, and continuity rules. |
| `storyboard-board-architect` | Specify storyboard board graphics, panel layout, labels, hierarchy, and board text. |
| `copy-voice` | Produce or polish copy, VO, dialogue, captions, supers, product text, and tone. |
| `image-prompting` | Produce final static image prompt packs with visible-text and reference constraints. |
| `video-prompting` | Produce final video prompt packs with timing, motion, continuity, and acceptance criteria. |
| `tool-routing-cost` | Plan execution only when the user explicitly asks to use their own configured tools. |
| `execution-manifest` | Record approved execution parameters, source assets, output plan, and risk notes. |
| `asset-manifest` | Index output files, versions, source traceability, exclusions, and reproducibility notes. |
| `qa-iteration` | Review outputs, prompts, and artifacts against brief, references, locks, and acceptance criteria. |
| `delivery-documentation` | Package accepted files, QA status, usage notes, caveats, and delivery manifest. |
| `hyperframes-producer` | Plan coded-video structure, animation system, captions, render QA, and manifest details. |

For detailed inputs, outputs, gates, and common handoffs, see [Agent Roster](agent-roster.md).

## Roles Vs Skills

Roles and skills are intentionally not a one-to-one list.

- **Role-agent templates** are active Codex handoff actors. They own workflow state, artifacts, review gates, and next handoff decisions.
- **Workflow skills** are reusable contracts or knowledge packs. They describe when a capability should be used, what inputs it needs, what it should produce, and which safety rules apply.
- Some skills share a name with a role because the role and support contract are tightly coupled.
- Some skills support broader roles instead of becoming separate roles. For example, `output-critic-iteration` supports the `qa-iteration` role, `storyboard-director` supports `storyboard-architect`, and the commercial, cinematography, storytelling, marketing, character, and UGC skills support direction, copy, storyboard, image-prompting, and video-prompting routes.

The canonical role-to-skill map lives in [`role-skill-map.md`](../.agents/skills/pipeline-core/references/role-skill-map.md). A handoff such as `static-direction` names a workflow responsibility, not necessarily a same-named native ChatGPT skill. ChatGPT should resolve the role through that map, load the smallest supporting skills, create a temporary responsibility for the current task, and avoid inventing a missing same-named skill.

This keeps the installed role roster stable while still giving the workflow domain-specific support where it is useful. A skill that is not listed as a role is not dead by default; check [Workflow Map](workflow-map.md) and the [Role To Skill Map](../.agents/skills/pipeline-core/references/role-skill-map.md) for its supporting route.

## Installed Workflow Skills

Skills are portable workflow contracts. They define when a capability should be used, what input it needs, what artifact it should produce, and which safety rules apply. Codex discovers the source folders locally; ChatGPT Work reads the declared repository sources after the README prompt invokes `@skill-creator`, then creates the selected native Skills through Create with chat. They are not paid provider integrations.

| Skill | Main use |
| --- | --- |
| `asset-manifest` | Organize workflow assets, file lists, versions, source traceability, exclusions, and reproducibility notes. |
| `brief-architect` | Convert messy notes, user requests, source material, and constraints into a Brief Contract. |
| `caption-studio` | Plan, style, normalize, repair, and QA captions, subtitle timing, safe zones, and render or edit handoffs. |
| `character-design` | Build character design systems, identity anchors, expression sheets, outfit variants, and consistency rules. |
| `cinematography` | Plan shot language, lens choices, camera movement, lighting, blocking, color, texture, and cinematic direction. |
| `commercial-video-campaign-director` | Create motion direction for commercial video campaigns, product reveals, social clips, and launch videos. |
| `commercial-visual-campaign-director` | Create static campaign and graphic direction, concepts, poster/cover/menu/label layouts, source-aware variants and optional poster-code interpretations. |
| `copy-voice` | Produce or refine campaign copy, VO, captions, supers, dialogue, and final text while preserving locked facts. |
| `creative-music-video-director` | Translate song context, artist persona, motifs, rhythm, and emotional arc into a music-video direction contract. |
| `creative-video-producer` | Coordinate complete video production packs across strategy, story, storyboard, prompts, audio, captions, editing, QA, and delivery. |
| `delivery-documentation` | Package final files, QA status, source lists, usage notes, caveats, excluded files, and delivery manifests. |
| `ecommerce-campaign-strategy-director` | Turn product and offer truth into audience/JTBD, campaign thesis, asset matrix, claim ledger, and creative testing handoffs. |
| `hipson-adapter` | Create lightweight Hipson-style research maps, internet mapping packets, bounded instruction packets, review packets, and execution packets. |
| `humanizer` | Polish writing, copy, VO, dialogue, tone, final summaries, and reduce generic AI phrasing while preserving facts. |
| `hyperframes-workflow` | Plan HyperFrames coded-video structure, implementation prompts, GSAP-style timing, captions, overlays, render QA, and delivery manifest requirements. |
| `image-prompt-architect` | Create final image prompt packs, integrated static graphics, typography feasibility and scoped edits from approved brief, references, direction and copy. |
| `instruction-packet-factory` | Create bounded instruction packets, research maps, review packets, and execution packets for workflow roles. |
| `marketing` | Plan campaigns, offer framing, asset matrices, audience fit, channel adaptation, launch kits, and campaign QA. |
| `onboarding-preference-tuning` | Run first-time setup for preferences, local display names, output paths, QA strictness, delivery behavior, and optional expansions. |
| `opencut-video-studio` | Prepare local OpenCut asset bins, edit decisions, timeline maps, variants, export targets, and QA contracts. |
| `output-critic-iteration` | Review produced outputs against brief, references, prompts, copy locks, observables, and acceptance criteria. |
| `pipeline-core` | Route workflows through roles, gates, handoffs, artifacts, request diagnostics, reasoning routes, Loop Protocol, QA, delivery, and governance. |
| `reference-pack-curator` | Structure references into canonical sources, aliases, role tags, suppression rules, conflicts, and continuity anchors. |
| `research-evidence` | Verify claims, source-backed facts, tool limits, assumptions, and evidence boundaries. |
| `remotion-video-production` | Plan, implement, review, and QA deterministic React/TypeScript video compositions, reusable variants, and local Remotion renders. |
| `producer-ai-task-builder` | Build text-only music, music-video, visible-singing, lip-sync-triage, and repair task packets without provider execution. |
| `screenplay-story-architect` | Develop original loglines, pitches, treatments, beat sheets, scenes, dialogue, coverage, rewrites, and production handoffs. |
| `storyboard-board-architect` | Specify storyboard board, production board, or shot board graphics with panel structure and board copy. |
| `storyboard-director` | Convert direction into beats, scenes, shot cards, timing, transitions, and continuity rules. |
| `storytelling` | Plan narrative structure, story beats, emotional arcs, scene logic, continuity, and multi-shot workflows. |
| `tool-routing-cost` | Plan provider-neutral tool routing, cost preflight, upload boundaries, approval requirements, fallback limits, and execution risk. |
| `ugc` | Plan UGC-style creator ads, talking-head scripts, social proof concepts, hooks, and creator-read copy. |
| `video-prompt-architect` | Create final provider-neutral video prompt packs from approved storyboard, motion direction, references, and copy. |
| `workflow-orchestrator` | Route workflows, maintain project state, assign role-based agents, enforce gates, own Loop State, and decide loopbacks and stop decisions. |
| `workflow-self-improvement` | Run explicit-only retrospectives, workflow audits, improvement notes, and approval-gated change proposals. |

## Skill Groups

| Group | Skills | Primary role relationship |
| --- | --- | --- |
| Core routing and governance | `pipeline-core`, `workflow-orchestrator`, `onboarding-preference-tuning`, `tool-routing-cost`, `workflow-self-improvement` | Own install-time behavior, route selection, Project State, safe execution planning, onboarding preferences, and explicit-only improvement proposals. |
| Intake, references, evidence, and packets | `brief-architect`, `research-evidence`, `reference-pack-curator`, `instruction-packet-factory`, `hipson-adapter` | Support brief, evidence, reference, research, and bounded packet roles without installing full Hipson. |
| Creative direction and strategy support | `ecommerce-campaign-strategy-director`, `screenplay-story-architect`, `marketing`, `character-design`, `cinematography`, `commercial-video-campaign-director`, `commercial-visual-campaign-director`, `creative-music-video-director`, `storytelling`, `ugc` | Support ecommerce strategy, `static-direction`, `motion-direction`, `music-video-direction`, `storyboard-architect`, `copy-voice`, `image-prompting`, and `video-prompting`. |
| Video production, captions, and local editing | `creative-video-producer`, `producer-ai-task-builder`, `caption-studio`, `opencut-video-studio`, `remotion-video-production` | Coordinate complete video packs, text-only music/video task packets, caption contracts, timeline edit packs, and deterministic React/TypeScript compositions without bundling provider execution. |
| Prompting, boards, and coded-video planning | `image-prompt-architect`, `video-prompt-architect`, `storyboard-director`, `storyboard-board-architect`, `hyperframes-workflow` | Support prompt, storyboard, board, and HyperFrames routes. |
| QA, delivery, copy, and asset handling | `copy-voice`, `output-critic-iteration`, `asset-manifest`, `delivery-documentation`, `humanizer` | Support `copy-voice`, `qa-iteration`, `asset-manifest`, and `delivery-documentation` responsibilities. |

## Other Included Workflow Assets

| Asset | What it gives the user |
| --- | --- |
| `AGENTS.template.md` | Project instruction template for installed workspaces. |
| `config/artifact-schemas.json` | Required fields and example fixtures for workflow artifacts. |
| `config/provider-neutral-policy.json` | Public boundary for what the kit does and does not install or execute. |
| `config/text-image-policy.json` | Built-in Codex/ChatGPT image generation policy for static raster graphics with visible text. |
| `.agents/skills/pipeline-core/references/role-skill-map.md` | Machine-checked mapping between Codex role IDs, temporary ChatGPT responsibilities, and supporting public skills. |
| `.agents/skills/pipeline-core/references/prompt-format-and-continuity.md` | Generator-specific prompt-field rules and continuity-carrier requirements for independently generated images and shots. |
| `examples/*/workflow.json` | Checked example routes that demonstrate role order, gates, artifacts, and handoffs. |
| `scripts/install.mjs` | Project-local install, update, repair, uninstall, manifest, backup, and symlink safety logic. |
| `scripts/guided-install.mjs` | Beginner-safe guided install path with checks, onboarding, dry-run, and confirmation. |
| `scripts/doctor.mjs` | Preflight and install-health diagnostics. |
| `scripts/validate.mjs` | Repository workflow validation. |
| `CHATGPT_INSTALL.md` | Canonical English ChatGPT installation and post-install language contract. |
| `scripts/chatgpt-skill-sources.mjs` | Deterministic source-manifest generation and repository setup validation. |
| `config/chatgpt-skills.json` | Core, creative, and full ChatGPT repository-install profiles. |
| `config/chatgpt-skill-sources.json` | Exact raw source URLs and SHA-256 hashes for all public skills. |
| `scripts/audit-privacy.mjs` and `scripts/safety-scan.mjs` | Public-source privacy and secret scanning. |
| `tools/*` | Memory Cache, semantic memory, context budget, skill audit, and cleanup helpers. |

## What Is Not Included

- No paid external media-provider clients.
- No API keys or API-key setup flows.
- No endpoint catalogs for paid providers.
- No background daemon.
- No automatic upload or publishing.
- No global install unless the user explicitly chooses the guarded global mode.
- No full Hipson install. The included Hipson Adapter is lightweight; full Hipson remains separate and optional.

## Related Docs

- [Quickstart](quickstart.md)
- [Workflow Map](workflow-map.md)
- [Agent Roster](agent-roster.md)
- [Workflow Stages](workflow-stages.md)
- [Architecture](architecture.md)
- [Provider-Neutral Boundary](provider-neutral-boundary.md)
- [Compatibility](compatibility.md)
