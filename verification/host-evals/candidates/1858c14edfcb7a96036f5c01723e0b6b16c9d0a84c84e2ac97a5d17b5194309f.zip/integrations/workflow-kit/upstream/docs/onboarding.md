# Onboarding

## Purpose

For native Codex Skills installed through `$skill-installer`, use the installed
`onboarding-preference-tuning` Skill to keep a visible Workflow Profile. It does
not require `framecore.config.json`, rendered agents or a project manifest.
The CLI procedures and generated files below apply only to the optional advanced
project-local mode. See [native installation](../CODEX_INSTALL.md).

Onboarding creates local configuration for one workspace. It should run before installation unless the user explicitly provides a complete `framecore.config.json`.

The workflow was created for creative work such as graphics, video, storyboards, campaign assets, e-commerce assets, prompt workflows, QA, and delivery preparation. It can be adapted to other use cases by profiling the workspace during onboarding.

The goal is not to change the public workflow logic. The goal is to tune how the installed workflow behaves in this one workspace: work profile, response tone, output location, QA strictness, local agent display names, delivery preferences, and optional expansion choices.

The guided installer invokes onboarding before dry-run and project-local install. That order matters because rendered agent files should use the final local config, not generic defaults.

Onboarding requires an existing target workspace by default. Use `--create-target` only when you intentionally want the onboarding command to create a new folder.

## Defaults

Default choices are conservative:

- project-local installation
- no automatic upload
- standard QA strictness
- creative work profile for graphics, video, storyboards, campaign assets, and e-commerce assets
- lightweight Hipson Adapter only
- recurring self-improvement review disabled
- neutral role IDs kept as display names unless the user chooses local names

If onboarding is skipped, the installer can still render agents with built-in defaults. That is useful for automation, but it gives the user a less personalized setup.

Use `--defaults` for a non-interactive guided setup when the target workspace should start with conservative defaults:

```bash
npm run install:guided -- --target /path/to/your/project --defaults --yes
```

## Interactive Questions

Interactive onboarding asks:

- Installation guidance and all CLI prompts are English. The default `working_language` is `auto`: the host resolves it after verified installation from an explicit preference, the user's own conversation, a reliably exposed host locale, or English as fallback. A copied English setup prompt is not a language preference. Existing explicit config values are preserved.
- `What kind of work do you do?`, the user's primary work context. The default is creative production: graphics, video, storyboards, campaign assets, and e-commerce assets.
- `What should this pipeline help with most?`, the user's main use cases, such as briefs, references, visual direction, prompt packs, QA review, and delivery preparation.
- `How should the pipeline fit your work style?`, the preferred operating style for route depth, checkpointing, and output shape.
- `Any adaptation notes for non-creative or specialized use cases?`, local guidance for adapting the creative workflow to another domain without changing provider-neutral safety boundaries.
- `Response tone`, the preferred communication style.
- `Output directory`, the local folder for workflow outputs and delivery material. Use a safe relative path such as `output/workflow`; do not use absolute paths, `~`, URLs, cloud sync paths, or machine-specific folders.
- `QA strictness`, one of `light`, `standard`, or `strict`.
- `Allow automatic delivery uploads if you later add a delivery integration?`, disabled by default.
- `Require an explicit user request before delivery/export?`, enabled by default.
- `Require QA approval before generated asset delivery?`, enabled by default.
- `Enable 24-hour workflow self-improvement review?`, disabled by default.
- `Connect the separate full Hipson system later?`, disabled by default. Full Hipson is a separate optional repository, not part of this install. It can later add broader repository scanning, change and delta reviews, sidecar review agents, cross-repo orchestration, CLI commands, and a larger Hipson knowledge base. In this workflow it acts as an optional expansion layer for deeper analysis and structured instruction packets. Onboarding records this preference only; it does not clone, install, or activate full Hipson.
- `Use default role names?`, enabled by default.

If the user chooses not to keep default role names, onboarding asks for a local display name for every neutral role ID. These display names are local preferences, not source repo names.

The work profile is saved to `framecore.config.json` as `work_profile`. Installed instructions and rendered core agent files use it to adapt routing, artifact depth, QA strictness, and the first recommended workflow path for the user's real work. The rendered workflow-orchestrator, QA, and delivery agents also receive the selected QA and delivery controls. These controls tune review depth and delivery behavior; they never grant provider, upload, or publishing permission.

## Installed Files

Onboarding itself writes:

- `framecore.config.json`
- `.framecore/automation-recipes/workflow-self-improvement-review.json` only when the recurring review is explicitly enabled

When `framecore.config.json` already exists, onboarding writes a numbered backup before replacing it, starting with `framecore.config.json.bak`, then `framecore.config.json.bak.1`, and so on.

Onboarding starts with effective built-in, shared and local preferences, in that
order. `--defaults` keeps those preferences; it does not reset an existing setup.
Only changed answers and previously explicit local fields are written locally.
An empty `{}` is valid and inherits the current defaults. Later shared changes
remain effective for fields that have no local override. Existing complete
local configs are preserved as explicit overrides, not silently reduced.

Each config layer must be a JSON object. Invalid JSON, arrays, strings, numbers
and `null` stop setup before configuration or managed-file writes. Numbered
backups skip occupied names, including dangling symlinks, and are created
exclusively so an existing backup is never overwritten.

The later project-local install writes managed workflow assets, rendered agent files, project instructions, and `.framecore/manifest.json`.

When a later update or repair rewrites the manifest, the previous manifest is saved as `.framecore/manifest.json.bak`, `.framecore/manifest.json.bak.1`, and so on.

## Completion Output

After writing `framecore.config.json`, onboarding prints the next safe steps:

- run install dry-run against the target workspace
- review planned writes and user-owned file conflicts
- install project-locally
- open the target project in Codex
- ask Codex to read `AGENTS.md` and `AGENTS.framecore.md` when both exist
- use `docs/using-the-kit.md` for starter prompts and route selection

This output is guidance only. Onboarding does not install managed workflow files by itself.

## Maintainer Profile Simulations

The repository includes deterministic sandbox simulations for three Codex onboarding profiles and all three ChatGPT installation profiles:

- beginner solo creative work with light QA
- strict client or team work with strict QA
- non-creative research and document work with standard QA
- ChatGPT `core`, `creative`, and `full` source resolution
- update of an existing Codex install without losing its local profile

Run them with:

```bash
npm run smoke:profiles
```

The Codex simulations perform onboarding, dry-run, project-local install, doctor checks, rendered-agent checks, and update checks inside temporary workspaces. The ChatGPT simulations verify that each declared profile resolves only repository-owned skill sources and never installs Codex agent files. They do not replace a live account-side ChatGPT UI test, because ChatGPT availability and interface behavior are controlled by the host account.

## Hipson Adapter And Full Hipson

This repo includes the lightweight Hipson Adapter. Inside this architecture it works as a packet layer for:

- research maps
- internet mapping packets
- bounded agent instructions
- review packets
- execution packets

Full Hipson is separate and optional:

https://github.com/Hipson47/Hipson.git

If the user connects the full Hipson system later, it can add broader repository scanning, delta reviews, sidecar review agents, cross-repo orchestration, CLI commands, and a larger Hipson knowledge base. The adapter is enough to use this workflow without that expansion.

Onboarding does not clone, install, or activate full Hipson. It only records whether the user intends to connect that optional external extension outside this kit.

## Safety Boundaries

Onboarding does not change public workflow logic:

- skill contracts
- role IDs
- gates and handoffs
- provider-neutral boundary
- privacy rules
- installer safety rules

Delivery preferences only shape local behavior. They do not add cloud credentials, upload targets, external execution tools, or provider-specific delivery integrations.

Existing project instructions are protected. If a target workspace already has `AGENTS.md`, project-local install writes the workflow instructions to `AGENTS.framecore.md` unless the user explicitly passes `--force`.

## Post-Install Language Checks

After verified installation, try an ordinary task in the user's own language
while leaving the copied English setup prompt in the conversation. Explanations
should follow the user, not the copied prompt. Then request a different language
for one deliverable and confirm that only that deliverable switches. Exact
artwork copy must remain unchanged. Confirm that an explicit stored preference
is preserved and that unavailable locale information is not invented.

These are live host behavior checks. Passing source, metadata and CLI tests
does not prove native activation or model language selection.

## Generated Files

User-specific onboarding files should stay local to the workspace where they were generated. Do not commit local config, local agent display names, private project context, secrets, local paths, private cloud links, generated outputs, or delivery material unless the team intentionally accepts that scope.
