---
name: humanizer
description: Polish existing copy, headlines, short voice-over or editorial text for natural rhythm, specificity and voice without changing facts or locks. New copy goes to Copy Voice.
---

# Human voice

Before final delivery of a substantive authored, revised or generated creative artifact, automatically apply [output review](../pipeline-core/references/loop-protocol.md#automatic-output-review). Reuse domain QA in one bounded loop; inspect actual media, preserve accepted locks and stop unchanged on a pass. This does not run for greetings, menus or onboarding questions. When Superpowers is in the skill list, load `superpowers:systematic-debugging` before diagnosing a reproducible technical defect and `superpowers:verification-before-completion` before calling a deliverable ready; Studio keeps ownership.

Polishing removes the [AI writing patterns](../copy-voice/references/ai-writing-patterns.md) without sterilising the voice: look for clusters, not single tells; keep specific human detail, varied rhythm and a supplied writing sample's habits; never add a fact to sound more human. Where code runs, check the before and after with [`ai_writing_check.py`](../copy-voice/scripts/ai_writing_check.py).

**Out of scope first.** If the request belongs to another owner, load that owner's skill and continue there; do not produce its deliverable here. A request for new copy ("napisz od zera", a product description from nothing) goes to [Copy Voice](../copy-voice/SKILL.md). Never add a health, comfort, safety or performance claim that the source text does not contain.

Read [copy and voice](references/copy-and-voice.md) for focused voice polish and bounded edits. [Copy Voice](../copy-voice/SKILL.md) owns new commercial/editorial text and its Copy Pack; support it without restarting intake. Within a static-design project apply the relevant copy craft inside the existing design contract. Authored narrative scenes, scene dialogue and dramatic structure belong to [screenplay-story-architect](../screenplay-story-architect/SKILL.md); lyrics and song-production text belong to [audio-production-director](../audio-production-director/SKILL.md). Share copy locks without transferring ownership.

For a voice that needs calibration across contexts, evidence-sensitive editorial work or a revision that risks adding claims, use [the applied voice workshop](references/applied-voice-workshop.md) and its optional worksheet/example. Do not require a voice system for a single mechanical correction.

Apply the conditional [public research gate](../research-evidence/SKILL.md) before substantive drafting or revision. Verify material public factual claims with authoritative sources; search audience, medium, language or genre context only when a trigger applies. Use findings to sharpen original wording, never to lift another writer's lines or disclose private copy.

Understand speaker, audience relationship, purpose, facts, medium and requested extent. Ask only for a missing fact that changes the message. Write the requested artifact, not a list of headings. A CTA can be plain; a scene or VO may need spoken cadence; neither needs manufactured informality.

For substantive commercial persuasion, headlines or slogans, use the commercial-strategy checkpoint in [copy and voice](references/copy-and-voice.md#commercial-copy-strategy). Keep it internal and proportional: do not expose a long intake form, force a framework, or create extra routes when the brief already settles the message.

Separate draft permission from final selection. User-supplied final text is locked unless revision is requested. A precise replacement instruction authorizes that exact change. Broad “make it better” permits candidates, not silent use of a new slogan in a graphic.

Review meaning, specificity, truth, contribution, natural rhythm and fit. Remove interchangeable promises and unsupported urgency. Do not insert errors, fake slang or invented experiences to appear human. Do not claim the text was human-authored.

Return the requested quantity and format. Explain only a material tradeoff. If the text belongs to a graphic, hand off exact selected strings, language, hierarchy, factual status and allowed breaks, not a paraphrase.

## Integrated workflow contracts

Use [the integrated workflow-kit method](kit/method.md) for this owner’s artifact fields, bounded review and downstream handoffs. Read [Studio integration authority](../pipeline-core/references/studio-integration-policy.md) for precedence and the single active route. Preserve this owner’s domain craft and the user’s requested stage.

## Copy ownership

Use [Copy Voice](../copy-voice/SKILL.md) to own new commercial/editorial copy and the ready-to-use Copy Pack. Humanizer owns focused naturalness and voice repair. A direct short polish request stays here; it does not start a second intake or editorial loop. Narrative scene authorship stays with Story And Screenplay and lyrics with Audio Production.
