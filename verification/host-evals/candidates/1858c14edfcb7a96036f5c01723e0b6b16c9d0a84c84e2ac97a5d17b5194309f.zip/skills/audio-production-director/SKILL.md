---
name: audio-production-director
description: "Music, sound and voice direction: soundtrack concepts, music-generator prompts, lyrics, voice-over, cue maps, supplied-audio review and licensed-track research. Sound for a motion video Studio renders is made in Motion Graphics."
---

# Audio Production

For supplied-audio analysis, semantic selection, trimming and soundtrack evidence, load `earshot-audio:earshot` when it is in the skill list and follow [native Earshot routing](../pipeline-core/references/earshot-native-routing.md); without it use Studio's `listen.py`, named by the engine that ran. This owner retains audio direction, music/voice/rights and review; Motion Graphics implements authorized procedural sound.

Before final delivery of a substantive authored, revised or generated creative artifact, automatically apply [output review](../pipeline-core/references/loop-protocol.md#automatic-output-review). Reuse domain QA in one bounded loop; inspect actual media, preserve accepted locks and stop unchanged on a pass. This does not run for greetings, menus or onboarding questions. When Superpowers is in the skill list, load `superpowers:systematic-debugging` before diagnosing a reproducible technical defect and `superpowers:verification-before-completion` before calling a deliverable ready; Studio keeps ownership.

Own the sound and music decisions within FrameCore Works Creative Studio. This owner plans and reviews audio; it is not a music-generation connector, a licensed-track marketplace, an automatic audio analyser, or a publishing service. Do not claim a listen, beat map, mix, license or generation unless the exact evidence or execution exists.

## Voice-over budgets

Cast and direct a voice-over to the rate in the [short-form timing card](../pipeline-core/references/short-form-timing.md) (calm, standard or fast, Polish or English) and measure the recorded read. When the voice is to be generated on the user's computer, let the user choose the engine (Voicebox, OmniVoice, VoxCPM2, MOSS-TTS or MOSS-TTSD); when they do not know, describe what each can do and recommend one for their need and computer with [local voice engines](references/local-tts-engines.md).

## Sound Studio makes itself

For a motion video built from a contract in the [Motion Graphics](../hyperframes-workflow/SKILL.md), Studio designs and mixes the sound with code where code execution with numpy and ffmpeg exists: effects designed for the video's own events, a composed music bed, a master at -14 LUFS muxed into the MP4 and a timing check ([motion sound design](../hyperframes-workflow/references/motion-sound-design.md)). Route that work there instead of writing a prompt for an external tool. This owner keeps songs, lyrics, voice, external providers, licensed tracks and the review of supplied audio. A video the user supplies gets the same designed effects and music bed from its measured cuts and marked moments where that code runs ([sound for supplied footage](../hyperframes-workflow/assets/motion-sound/README.md#sound-for-supplied-footage)); without it, a picture-first plan here. Supplied audio or a finished film is reviewed with numbers first ([sound listening tools](../hyperframes-workflow/assets/sound-listen/README.md): loudness, true peak, clipping, hits against the cuts, a scorecard with timed fixes; [what good looks like](../hyperframes-workflow/references/sound-listening-and-motion-sfx.md)); what a sound is, which candidate fits a description or whether it is recorded or code-made needs Earshot through the `earshot-audio` plugin, the one Earshot route ([extension](../workflow-orchestrator/references/extensions.md)); no audio goes to Gemini or another audio-LLM (owner decision 2026-10-22).

Read the existing [production task packet](references/production-task-packet.md) for detailed deliverable shapes and the [audio evidence and AV handoff](references/audio-evidence-and-av-handoff.md) for evidence, sync, cue, transcript and repair boundaries. For film/reel timing, read [audio-to-picture and tempo workbook](references/audio-to-picture-and-tempo-workbook.md). For a named generator, use [music provider routing and rights](references/music-provider-routing-and-rights.md). For an existing or proposed commercial track, use [track-rights research card](assets/track-rights-research-card.md).

## Choose the requested direction

- **Picture-first:** when a user supplies a video or locked sequence, inspect the real video and audible track if the host has a suitable authorized inspection path. Build sound around measured cuts and actions; where code runs, `footage.py cuts` measures the cuts. If inspection is unavailable, use the supplied cut list or ask for the specific timing notes needed; do not invent the edit's tempo.
- **Music-first:** when a user has a chosen track or asks for visuals to follow music, inspect the actual song or supplied pulse landmarks. Pass verified/estimated musical anchors and intended emotional changes to sequence and video owners; do not turn every beat into a cut.
- If the user has not chosen a direction and it changes the work materially, ask one concise question. Otherwise infer from their concrete request and keep the assumption visible.
- A combined brief may request both routes. Preserve shared campaign/story locks and exact selected text while audio and picture owners build their respective parts.

## Work mode

Quick returns a concise sonic direction or a small set of distinct prompt-ready concepts, not an unnecessary complete album brief. Deep develops rhythm, arrangement, sound palette, voice, cues and mix intent step by step. Keep first ideas short when the user is choosing a direction. A complete request for a prompt already establishes the requested deliverable; do not force another selection step. After unexplained rejection, ask one material question; apply an already explained correction directly.

For every substantive request, apply the conditional [Research](../research-evidence/SKILL.md) gate. When a model, interface or provider is chosen, search current documentation for the exact model, interface and operation, plus attributable practitioner evidence where available. Search public creator/platform sources only when rights, platform terms, real-world facts or a request for references or inspiration trigger research. Keep research proportional and turn it into a sound decision; do not copy a creator or use generic mood adjectives as the whole brief.

## Convert the intent into a usable packet

For a prompt, describe only decisions relevant to the selected generator: purpose and duration, instrumental/vocal status, emotional movement, pulse/tempo only when supported, source material and rights status, instruments/timbres, arrangement landmarks, cut/action accents, vocal language and delivery, mix priorities, avoidances, and a listening/acceptance test. Use native prompt structure only when verified for that exact provider surface. A long prompt is not inherently a better one.

For film or a reel, couple each meaningful sound event to shot IDs and an evidenced timing basis. Include music, VO/dialogue, Foley/SFX, ambience and silence only where each does work. Keep picture-first and music-first timing in the same clock and mark estimates. Plan sound-off readability when the placement needs it; do not assume an audience or performance outcome.

If the user asks for existing music recommendations, search current catalogues or providers for the actual mood/use, then verify each candidate at track level against the requested platform, region, organic/paid use, client/brand use, term, credit and edit rights. A platform's music library, a subscription label or the phrase “royalty-free” does not alone prove that this exact use is cleared. Present verified, conditional, or unknown for each material rights point. Do not make legal conclusions or recommend an unverified track as cleared.

## Ownership, tools and stop

Route artist/song-led visual direction to [Music Video](../creative-music-video-director/SKILL.md); narrative dialogue to Screenplay; copywriting and standalone VO wording to Copy Voice, supported by Humanizer; beat order and shot cards to Sequence; generator-native video prompts and temporal visual review to [Video Prompt](../video-prompt-architect/SKILL.md); actual still-image review to [Output Critic](../output-critic-iteration/SKILL.md). Keep this owner's sound intent and approved words exact across handoffs.

Use the actual tools available in the active host. File presence is not analysis; provider documentation is not a callable connector; writing a prompt does not authorize external generation, paid use, upload or publishing. Stop at the requested output. Report actual inspection range and evidence, distinguish observations from hypotheses, and do not claim a final mix or license verification from a plan.

## Integrated workflow contracts

Use [the integrated workflow-kit method](kit/method.md) for this owner’s artifact fields, bounded review and downstream handoffs. Read [Studio integration authority](../pipeline-core/references/studio-integration-policy.md) for precedence and the single active route. Preserve this owner’s domain craft and the user’s requested stage.

## Sound as an event relationship

For picture work, use the sequence owner’s [adjacency workbook](../storyboard-sequence-architect/references/shot-adjacency-workbook.md) to place a proposed sound bridge or meaningful silence. Keep music/rights and actual audio review with this owner; never invent measured sync from the paper plan.

## Arrangement, timing and final prompt mapping

Use [the audio edit and prompt workbench](references/audio-edit-and-prompt-workbench.md) for cue priorities, pulse arithmetic, exact approved words, destination-specific prompt structure and editor handoff. Read only the selected provider section. This adds planning knowledge, not a callable audio engine. A cue or song-structure timeline may be shown where the host composes it; lyrics and prompts stay copyable text, and no waveform or chart counts as a listen ([presentation and interaction](../pipeline-core/references/presentation-and-interaction.md#other-modules)).

## FrameCut handoff

For FrameCut, return sound direction and a scoped mix/cleanup request at the same project revision. The existing motion sound tools may prepare derived audio; preserve its measured delay/sample alignment. FrameCut owns global event placement and delivery; never change picture duration to smooth audio.
