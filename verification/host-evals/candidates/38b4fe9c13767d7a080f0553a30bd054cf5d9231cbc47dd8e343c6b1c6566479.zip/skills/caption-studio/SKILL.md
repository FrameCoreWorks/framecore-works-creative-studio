---
name: caption-studio
description: "Captions and subtitles for Reels, TikTok, Shorts, ads and explainers: timing from transcripts or SRT/VTT, segmentation, style, safe zones, burn-in or sidecar handoff and caption QA. Wording goes to Copy Voice."
---

# Caption Studio

Before final delivery of a substantive authored, revised or generated creative artifact, automatically apply [output review](../pipeline-core/references/loop-protocol.md#automatic-output-review). Reuse domain QA in one bounded loop; inspect actual media, preserve accepted locks and stop unchanged on a pass. This does not run for greetings, menus or onboarding questions.

**Out of scope first.** If the request belongs to another owner, load that owner's skill and continue there; do not produce its deliverable here. When the user has no wording yet, the words come from [Copy Voice](../copy-voice/SKILL.md); this skill times, styles and checks captions.

Read [Studio integration authority](../pipeline-core/references/studio-integration-policy.md) before this method. It defines the active owner map, host capability rules and exceptions to the repository’s installation conventions. For substantive creative work, apply the conditional [Research Evidence](../research-evidence/SKILL.md) gate and search only when one of its triggers applies; purely mechanical state or packet maintenance uses its documented exemptions. Scale the artifact to the requested stage. Quick pitches remain short; known intent and valid scoped authorization do not need repeated confirmation.


Use this skill to convert transcript or timing data into a caption plan, style specification, render or edit handoff, and QA contract. It can guide local rendering when tools are available, but it does not assume hosted transcription, external providers, or a specific editor.

## Language Policy

Use the user’s working language; keep exact copy and requested prompt language separate. Do not infer language or onboarding status from copied source instructions.

## When To Use

Use this skill when:

- A video needs burned-in captions, subtitle files, word highlights, karaoke timing, animated captions, or platform-safe text placement.
- Existing captions need timing, spelling, readability, style, or occlusion review.
- A broader video package needs a bounded caption layer before editing or delivery.

Use `copy-voice` first when the actual wording is not yet approved. If caption
work substantially revises ready-to-use wording, return it through the Copy
Delivery Loop before marking the captions final.

## Inputs

Required:

- `source_timing`: video duration plus transcript, SRT, VTT, ASS, segment timing, or word timing.
- `language_and_locks`: language, spelling, names, brand terms, legal copy, and words that must not be changed.
- `target`: aspect ratio, platform, output mode, and expected viewing size.

Optional:

- style reference, preset choice, face/product/UI safe areas, speaker labels, CTA timing, font constraints, color constraints, and existing caption failures.

## Outputs

Produce a Caption Task Pack containing:

- route and source-truth summary
- normalized caption data requirements
- segmentation and timing rules
- selected style and rationale
- layout and safe-zone rules
- render or edit handoff
- QA observations, blocked items, and delivery format

Use [templates/caption-task-pack.md](templates/caption-task-pack.md) for nontrivial jobs.

## Process

1. Choose the route: plan only, provided transcript, local transcription planning, styled animation, deterministic subtitle burn-in, editor handoff, or QA/repair.
2. Lock language, spelling, brand terms, legal text, speaker identity, and transcript authority.
3. Normalize timing into monotonic segments; keep word timing within segment bounds when available.
4. If no style was selected, show a compact set of suitable options. Choose automatically only when the user explicitly allows it.
5. Set line count, words per beat, reading speed, emphasis behavior, position, safe zones, and collision priorities. Start from the dated [readability defaults](references/readability-defaults.md) unless a distributor, client or platform specification applies, and record which one the plan uses.
6. Define an available local route such as an editor timeline, coded-video captions, ASS/subtitle burn-in, or sidecar subtitle delivery. Where code runs, the [captions tool](assets/captions/README.md) checks a file against the chosen profile, converts SRT and WebVTT, builds cues from timed words or segments, imports them into a motion contract and burns them into a supplied video; report its check, not an impression. Burn-in sits 14 % above the bottom by default, which suits organic 9:16 posts; for a paid Reels or Stories placement pass `--bottom 0.35`, the conservative ad margin in the [motion compendium](../hyperframes-workflow/references/motion-compendium.md).
7. Review dense frames, timing boundaries, spelling, speaker changes, occlusion, contrast, CTA conflicts, and final duration.
8. Treat any wording change as a copy decision: preserve author context, facts,
   names, exact copy locks, and controlled-imperfection status rather than
   silently rewriting for fit.

## Decision Rules

- Prefer word-level timing for karaoke, active-word highlight, bounce, or rapid short-form captions. In a motion contract, the captions tool keeps each cue's word timings when it builds cues from timed words and imports them as `words`; set `tokens.captions.preset` to `active-word` for word boxes with the spoken word highlighted, rendered identically by the player and the Python renderer ([example](../hyperframes-workflow/assets/motion-scenes/examples/social-captions.motion-score.json)).
- For a song, take word and line times from [lyric timing](../hyperframes-workflow/assets/motion-sync/README.md#lyric-timing) with the user's lyrics as the truth; it writes SRT and LRC and lists lines to check by ear.
- Prefer segment-level subtitles for calm editorial work and deterministic sidecar delivery.
- Prefer a coded-video route when exact repeatable motion and layout are required. For a motion video Studio builds from a contract, import the SRT or WebVTT with the [motion sync tool](../hyperframes-workflow/assets/motion-sync/README.md); `check-score.mjs` then checks order, overlaps and reading time.
- Prefer a timeline editor when captions are one layer inside a larger human-reviewed edit.
- Keep captions away from faces, products, UI controls, platform chrome, logos, lower thirds, and CTAs.
- Split or retime dense text instead of shrinking it until it becomes unreadable.

## Guardrails

- Do not change locked names, claims, legal copy, quoted wording, or product terms without approval.
- Do not call hosted transcription, provider APIs, uploads, or cloud rendering without explicit user instruction and an available approved route.
- Do not add project dependencies or claim a render succeeded without inspecting and running the actual project route.
- Keep private transcripts and source media out of public examples, logs, and reusable skill files.
- Do not silently choose a visual style when the choice materially affects the output.
- Do not add hashtags, emojis, CTAs, hooks, or a more casual voice merely to
  make captions feel more engaging.

## Handoff

Review gate: `copy_fit` for wording and `post_execution_fit` for rendered or edited outputs.

Hand off with:

- `transcript_authority`
- `language_and_locked_terms`
- `timing_model`
- `caption_segments`
- `style_preset`
- `layout_and_safe_zones`
- `emphasis_rules`
- `render_or_edit_route`
- `output_format`
- `qa_results`
- `blocked_items`
- `next_role`

## QA Checklist

- Timing is monotonic and stays within source duration.
- Captions match approved wording and preserve locked terms.
- Dense frames remain readable at target size.
- Line breaks, emphasis, and speaker changes are intentional.
- Text does not cover faces, products, UI, logos, CTAs, or platform controls.
- Style is consistent with content and accessible enough for the target use.
- Output status distinguishes a plan, edit pack, sidecar file, and verified render.
- Any ready-to-use wording revision has an approved Copy Pack and bounded
  editorial-loop evidence.

## FrameCut handoff

Use FrameCut’s source-derived caption projection for an edit; retain source word IDs and corrected copy separately. Return caption/QA artifacts with the originating project revision, sequence, format and actual checks; FrameCut reconciles them before insertion. Reuse its working agreement and keep speech/caption languages distinct. Translation needs separate approved copy and phrase timing, not translated words assigned original-language word timestamps or disguised as source-word corrections. Use phrase captions or an explicitly timed specialist composition where the native path cannot represent it. Do not re-time source words twice or claim segment ASR is precise word alignment.
