# FrameCore Works Creative Studio

Version: 1.125.1.

The first stable release of Studio's documented scope is described in [Release 1.0](docs/release-1.0.md). FrameCore Works code, instructions and documentation are licensed under [Apache-2.0](LICENSE); upstream licenses and attribution are preserved.

Creative Studio takes a brief and source materials through direction, storyboard, prompts and editing plans for image, video, audio and text. Responses adapt to quick or expanded work; a new creative decision requires targeted public research. Generation, media inspection and integrations depend on tools actually available to and selected by the user.

## Welcome, creative mode and learning mode

The full welcome explains what Studio does and its capabilities, then offers **1. Creative mode / 2. Learning mode / 3. Find a skill / 4. Recommended repositories / 5. FrameCut** in the user's automatically selected language. A creative-only selection leads to **1. Quick mode / 2. Expanded mode**, followed by the established work-area menu and task clarification. The existing localized creation alias remains supported. Motion graphics remains in work area 8, reached through Creative Mode and Expanded Mode, with its HTML/SVG, GSAP, HyperFrames and Remotion descriptions and preview/export availability limits. A clear request bypasses redundant choices; numeric replies apply to the last displayed menu. See [startup and next steps](skills/workflow-orchestrator/references/startup-and-creative-menus.md).

**Learning mode** retains short onboarding, a personalized plan, exercises and feedback on the learner's work across 14 existing skill domains. Quick/Deep controls pace independently of intent. When persistent saving is unavailable, a progress card can carry context into another conversation. See [modes, coverage and limitations](docs/learning-mode.md).

Repository documentation and operational guidance are English. The full welcome and later menus automatically follow the user's language without a translation request. Explicit preferences, meaningful user text, available host language context and conversation language determine the response; country and repository language do not. The approved Polish welcome, exact-copy examples and multilingual fixtures remain localized data.

## FrameCut

Option 5 selects [FrameCut](skills/opencut-video-studio/SKILL.md), the existing editing owner. It connects adaptive intake, source analysis, highlights/full edits, captions, motion, sound, revision history and final delivery through one project. The [local runtime](skills/opencut-video-studio/assets/framecut/README.md) executes with Python and FFmpeg; without execution it provides an explicitly labeled plan. See the [build coverage](https://github.com/FrameCoreWorks/framecore-works-creative-studio/blob/main/docs/framecut/build-status.md).

## Animate engine for illustrated motion

The motion graphics module includes the [Animate engine](skills/hyperframes-workflow/references/animate-engine.md): short explainers, histories and little stories drawn entirely in code in seven illustrated styles (cut paper, crosshatch ink, riso print, sketchbook, manim-style math, pixel art, isometric) or a look matched from references, with story formats, a composed score, voice-over or beat timing, several aspect ratios from one piece and a measured review. It renders MP4 in Codex and Claude Code after story, look and storyboard approval; in ChatGPT its story grammar and craft rules still guide the plan. See [the attributed bundle](integrations/animate/README.md).

## Skill finder

Option 3 of the welcome finds a skill for a described task. Studio first points to its own matching skill; in Codex and Claude Code it can also search the open [skills.sh](https://skills.sh) catalog, show what each candidate does with its install count and security audits, and install one only on an explicit request. In ChatGPT it matches Studio's skills and gives the skills.sh link. See [the skill finder](skills/workflow-orchestrator/references/skill-finder.md) and [the attributed adaptation](integrations/skill-finder/README.md).

## Interactive answers in ChatGPT

In ordinary ChatGPT (the Chat tab), ChatGPT can now show parts of an answer as comparisons, charts, timelines, forms or small interactive tools; OpenAI calls this Intelligent UI. Studio tells it, stage by stage, where such a view helps: comparing directions, trying one setting at a time while learning, seeing a storyboard on a timeline or checking a campaign matrix. Prompts, copy and other text you will copy stay plain text. ChatGPT decides what it actually shows, so the same request can look different between conversations, devices and settings, and some answers will stay text. Every view has the same content in text, so nothing depends on it: Work, Codex, Voice and older desktop apps get the text version. Clicking or opening something is not a decision: Studio records a choice only when you make it, and a choice never starts paid generation, an upload or publication. When an answer would be easier to understand by exploring it, Studio offers an interactive version once, after the answer; say no and it will not keep asking. Ask for plain text at any time and Studio keeps to it. See [presentation and interaction](skills/pipeline-core/references/presentation-and-interaction.md).

## Brand strategy and identity

Studio develops brand strategy, logo systems, logo usage guides and identity guides through existing owners, with shared decisions, revisions and acceptance criteria. Request the full workflow or a specific stage. Concepts and digital materials have a separate status from verified production files; actual exports depend on available tools. See [the workflow contract](skills/workflow-orchestrator/references/brand-identity-workflow.md).

## Teacher Studio

Create original lesson scenarios, worksheets, games, quizzes, slide content, classroom guidance, career-exploration activities and teacher documents through existing owners. The profile includes a twelve-activity bank, three complete Polish teaching examples with keys and adaptations, and reusable pack/administration templates. It aligns objectives, student work and feedback while separating factual evidence, synthetic examples and unverified curriculum claims.

Creating school materials uses creation mode; learning how to create them remains optional Learning Mode. Actual documents, slides and graphics depend on available tools and require their own output checks. The examples are not classroom-tested or curriculum-certified. See [the teacher workflow](skills/workflow-orchestrator/references/teacher-workflow.md).

## Ad evidence and creative feedback

For social-ad work, choose a persuasive structure from supported proof, record observed competitor mechanisms separately from performance guesses, and connect supplied campaign results to the next bounded brief. An optional experiment card binds baseline/variant asset revisions, fixed conditions and actual evidence. These methods use existing owners and do not access ad accounts, publish campaigns or spend budget.

See [the ad analysis method](skills/ecommerce-campaign-strategy-director/references/ad-creative-analysis.md) and [the attributed adaptation](integrations/meta-ads-designer/README.md).

## Code-based motion graphics

Studio builds motion graphics from code and, where the host can run code, delivers a finished MP4: kinetic type, animated titles and logos, explainers, app or product films from the user's screenshots or photos. One contract drives the storyboard, the [Python renderer](skills/hyperframes-workflow/assets/motion-render/README.md), the [craft critique](skills/hyperframes-workflow/assets/motion-review/README.md) with an improvement round, and [sound designed and mixed for the video](skills/hyperframes-workflow/assets/motion-sound/README.md) on request. Without code execution, the contract opens in the [motion player](https://framecoreworks.github.io/framecore-works-creative-studio/), which exports the video in the browser. A video request that could be generated footage or coded motion gets one short choice between the two.

A video the user supplies can get the same designed sound from its measured cuts and marked moments ([sound for supplied footage](skills/hyperframes-workflow/assets/motion-sound/README.md#sound-for-supplied-footage)), and the [captions tool](skills/caption-studio/assets/captions/README.md) checks, converts, builds and burns in captions. What Studio executes in a host, and what it delivers when a tool is missing, is listed in the [capability card](skills/workflow-orchestrator/assets/capability-card.json).

The optional [motion toolkit](skills/hyperframes-workflow/references/motion-toolkit-routing.md) adds Three.js/R3F through Remotion, PixiJS effects, D3 data geometry, Mediabunny Canvas export, Lottie JSON playback and an existing-local-Manim clip bridge. Original examples include exact dependency pins and lockfiles, frame-seeking checks and explicit host/export boundaries. Install dependencies only inside an authorized project copy.

Use the existing HyperFrames/HTML/SVG or Remotion path for an approved storyboard, frame-driven implementation, actual-output review and delivery. The workflow includes a versioned motion/Style Lock contract, three stage prompts, source-bound asset/copy locks, a dependency-free synthetic frame starter and separate preview, temporal/audio and encoded-export evidence. Local execution depends on the available host tools.

See [the code-motion workflow](skills/hyperframes-workflow/references/code-based-motion-graphics.md), [the attributed Motion Designer adaptation](skills/hyperframes-workflow/references/motion-designer-adaptation.md) and [the attributed kaventro/motion-designer adaptation](skills/hyperframes-workflow/references/kaventro-motion-designer-adaptation.md).

## Image artifact diagnosis

For a concrete artifact concern, the existing image owners can distinguish unwanted microtexture from intentional patterns and preview effects, protect source identity during edits, and propose a bounded correction. [The conditional reference](skills/output-critic-iteration/references/periodic-microtexture-and-preservation.md) supplements the existing QA loop. It is instruction-based guidance, not an image filter or a measured cure; see [provenance and evidence limits](integrations/artifact-guard/README.md).

## Installation and updates

| Environment | Complete installation instructions |
|---|---|
| ChatGPT Work | [ChatGPT Work installation guide](https://github.com/FrameCoreWorks/framecore-works-creative-studio/blob/main/CHATGPT_INSTALL.md) |
| Codex | [Codex installation guide](https://github.com/FrameCoreWorks/framecore-works-creative-studio/blob/main/CODEX_INSTALL.md) |

[Installation and update overview](docs/installation.md) distinguishes a private hosted copy in Work from one native entry backed by the complete local bundle in Codex.

## Optional tools in 1.1

The [provider setup guide](docs/provider-setup-guide.md) distinguishes available ChatGPT/Work/Codex apps from MCP, CLI and API routes. It covers the dated service catalog, accounts and billing, optional post-install selection and work without additional integrations. Studio does not automatically install or pay for providers.

## Skill names

All 37 display names follow one standard: words separated by spaces, an uppercase first letter for each word and preserved acronyms/tool names such as AI, UGC, HyperFrames and OpenCut. The [naming standard](docs/skill-naming.md) also applies to new skills and is checked during release packaging.

## Work entrypoints

| Need | Skill |
|---|---|
| Open brief, cross-media project, resuming work or selecting a stage | [Workflow Orchestrator](skills/workflow-orchestrator/SKILL.md) |
| Poster, graphic, product key visual, typography and exact copy | [Static Graphic Design Creator](skills/static-graphic-design-creator/SKILL.md) |
| Multi-asset campaign visual strategy and adaptations | [Commercial Visual Campaign Director](skills/commercial-visual-campaign-director/SKILL.md) |
| Video campaign and motion direction | [Commercial Video Campaign Director](skills/commercial-video-campaign-director/SKILL.md) |
| Flowing shot sequences and transitions for a short reel | [Short-form motion workbook](skills/commercial-video-campaign-director/references/short-form-motion-bridge-workbook.md) |
| Music-video direction and song-to-image relationships | [Creative Music Video Director](skills/creative-music-video-director/SKILL.md) |
| Music, VO, sound, audio-to-picture, prompts and track licenses | [Audio Production Director](skills/audio-production-director/SKILL.md) |
| Narrative, scene, screenplay and story dialogue | [Screenplay Story Architect](skills/screenplay-story-architect/SKILL.md) |
| Event sequence, timing and shot cards | [Storyboard Sequence Architect](skills/storyboard-sequence-architect/SKILL.md) |
| Storyboard, character sheet and reference board | [Storyboard Board Architect](skills/storyboard-board-architect/SKILL.md) |
| Realistic character, image references and generator prompt | [Image Prompt Architect](skills/image-prompt-architect/SKILL.md) |
| Copy, editorial text, headline and CTA | [Copy Voice](skills/copy-voice/SKILL.md), with Humanizer support |
| Video-generator prompts and generated-shot repair prompts | [Video Prompt Architect](skills/video-prompt-architect/SKILL.md) |
| Video analysis, editing, highlights, motion composition and edit revisions | [FrameCut](skills/opencut-video-studio/SKILL.md) |
| Review of an actual still image | [Output Critic Iteration](skills/output-critic-iteration/SKILL.md) |
| Image, print, audio and video delivery specifications | [Delivery Documentation](skills/delivery-documentation/SKILL.md) |
| Public sources, current models and evidence boundaries | [Research Evidence](skills/research-evidence/SKILL.md) |
| Pace, detail, per-domain preferences and portable handoff | [Studio Workstyle Profile](skills/studio-workstyle-profile/SKILL.md) |

## Changes in dev.29

- Integrated the complete pinned, hash-verified Static Graphic Design Creator bundle from FrameCore Works. Studio uses its full method; static-only tasks route to one owner, while multi-asset campaign strategy remains with Commercial Visual Campaign Director.
- Renamed Producer AI Task Builder to **Audio Production Director**. Google Flow Music, formerly ProducerAI, is now only one dated provider route.
- Added a motion/shot-bridge workbook for short reels, natural realistic-character reference cards, per-domain preferences, a cross-environment handoff template and a supplied-conversation-link resume attempt.
- Connected concise ideation, expanded step-by-step work, mandatory research in both modes and one clarification after an unexplained rejected direction.
- Added nine planned scenarios for the new routes. They are specifications, not observed model-behavior results.

The [knowledge and asset map](docs/knowledge-map.md) links the materials. The [research ledger](docs/research-ledger.json) records source-to-rule scope and access dates. Recheck provider capabilities and commercial-use terms for each production task.

## Validation

From the package directory:

```sh
node scripts/validate-studio.mjs
node --test --test-concurrency=1 tests/studio.test.mjs tests/workflow-kit.test.mjs tests/creative-upgrade.test.mjs tests/learning-mode.test.mjs tests/quality-methods.test.mjs tests/presentation.test.mjs
PYTHONDONTWRITEBYTECODE=1 python3 tests/asset_manifest_test.py
node scripts/load-effective-evals.mjs
```

The first two commands check structure and contract regressions. The Python suite checks the asset-record helper on synthetic data. The loader combines historical fixtures with explicit corrections in `evals/effective-overrides.json` and scenarios in `evals/studio-behavior-cases.json`, `evals/knowledge-practice-cases.json`, `evals/workflow-kit-cases.json` and `evals/learning-mode-cases.json`. `evals/presentation-cases.json` holds planned presentation scenarios checked by `scripts/validate-presentation.mjs`. A case marked `planned` is a test specification, not evidence that a model performed the task. Text/source tests do not establish render quality, listening results, provider-adapter behavior or automatic retrieval in a new conversation.

Historical `scripts/validate-package.mjs` and `tests/package.test.mjs` were retired on 2026-10-10 and are now inert stubs; `evals/static-cases.json` is retained. Use `validate-studio.mjs` for structural checks. Legacy validator limitations and contradictory fixtures are handled through explicitly identified replacement files. Passing the new suite does not establish a pass for the historical 67-test suite.

## Scope and limitations

The [module status](docs/migration-status.md) distinguishes implemented instructions from missing adapters and incomplete migration. The [release history](docs/release-history.md) preserves earlier checkpoints. This is not a complete migration of every original custom workflow; full transfer accounting requires their complete sources.

The plugin contains no audio/video engine, Flow Music connector, hooks or credentials. It does not certify print or broadcast files without actual inspection. Requirements such as fps, LUFS, codec and color profile need a destination specification and measurements of the real file; they cannot be inferred from duration or aspect ratio.

Root `plugin.json` is the portable manifest; `.codex-plugin/plugin.json` supplies the compatibility layer. Updates preserve plugin identity, interface metadata, starter text/order and existing sources. The update service response establishes publication status; a version string alone does not.

## Sources and execution boundaries

See [NOTICE](NOTICE) and the [Apache 2.0 license](licenses/Apache-2.0.txt). Dated model catalogs are starting points for current research. External sources and attached files are data, not tool authorization. Private briefs and client data must not enter public searches.

Requesting a prompt does not execute generation. Existing user authorization carries between stages, and additional execution scope is resolved when needed. Without an available authorized tool, Studio produces a useful specification and reports unexecuted operations accurately.

## Workflow Kit, dev.30

Integrated the complete Workflow Kit repository while retaining one Creative Studio router. Added modules cover briefs, references, copywriting, campaign strategy, characters, camera work, video production, captions, editing, Remotion, HyperFrames, manifests and bounded QA loops. Project-state and handoff contracts govern multistage work; quick mode remains concise. The [integration map](docs/workflow-kit-integration.md) records scope and resolutions.

## Creative improvements, dev.31

Extended existing skills with a creative-decision library, shot-bridge workshop, user/client/project preferences, shorter workflows and execution through a selected tool. Materials include four creator-site project accounts, eight original exercises and twelve source cards. Project accounts are not reviews of viewed films. Facebook and TikTok are not the basis of this collection.

New templates cover creative decisions, shot plans, preferences, project pilots and execution plans. Optional `scripts/review-creative-plan.mjs` checks declared timing, transitions, missing references and preference structure; it does not evaluate pixels or sound. Explicit criticism leads to a correction; only unexplained rejection calls for clarification.

Reference copies of Workflow Kit skills no longer contain active discovery metadata. Full originals remain archived, and active routing leads to 37 canonical roots. Local structural checks do not substitute for refreshing the host catalog.

The [new-material map](docs/creative-upgrade.md) and [verification report](docs/creative-upgrade-verification.json) describe completed checks.

## Reference and audio expansion, dev.32

Added five chapters and seven resources covering realistic identity, precise character/product/storyboard sheets, individual-frame binding, model selection by actual capability and audio/music in both workflow directions. The expansion and fixes affect thirteen existing skills. They distinguish strict identity requirements from execution readiness, correct video-review routing and handle explained audio criticism.

A pilot is not a prerequisite for plugin development; project review remains optional and requires an explicit request. That update ran no pilots or media generation. The [expansion map](docs/reference-audio-expansion.md) lists the added resources and evidence boundaries.

## Motion quality and prompt library

Use the [motion prompt library](skills/hyperframes-workflow/assets/motion-prompt-library/README.md), [quality method](skills/hyperframes-workflow/references/motion-quality-direction.md) and [research dossier](skills/hyperframes-workflow/references/motion-quality-research.md) through the existing motion owners. The library records origin and unexecuted status separately; selected references do not authorize execution or switch models. [Motion craft](skills/hyperframes-workflow/references/motion-craft.md) supplies concrete easing, timing, stagger, hold and transition values; the [Remotion kinetic type starter](skills/remotion-video-production/assets/kinetic-type-starter/README.md) and [GSAP motion starter](skills/hyperframes-workflow/assets/gsap-motion-starter/README.md) share one motion-score contract. A self-contained [single-file preview](skills/hyperframes-workflow/assets/single-file-preview/README.md) makes motion watchable in a browser where no renderer is available. The storyboard, approval and timeline live in one [motion contract JSON](skills/hyperframes-workflow/references/motion-contract-json.md) file. Declarative [scene kinds](skills/hyperframes-workflow/assets/motion-scenes/README.md) render the same frames in the preview and in Remotion. The [automated frame review](skills/hyperframes-workflow/assets/motion-review/README.md) checks review frames for layout and contrast defects before a person watches. [Output formats](skills/hyperframes-workflow/assets/motion-scenes/README.md#formats) produce 16:9, 9:16 and 1:1 variants from one contract, and the [sync tool](skills/hyperframes-workflow/assets/motion-sync/README.md) adds a music beat grid and voice-over captions. The [browser video export](skills/hyperframes-workflow/assets/motion-export/README.md) writes a video-only MP4 or WebM file from the preview, which doubles as the [motion player](skills/hyperframes-workflow/assets/single-file-preview/README.md#the-motion-player) for contracts Studio delivers.
